#ifndef _GLCD_PROCESSOR_H
#define _GLCD_PROCESSOR_H

#if defined(__PIC32MX__)

    #include "glcd_p32xxxx.h"

#elif defined(__PIC32MZ__)

    #include "glcd_p32xxxx.h"
	
#elif defined(__PIC32WK__)

    #include "glcd_p32xxxx.h"
	
#else

    #error "Can't find header"

#endif

#endif//B_USB_PROCESSOR_H
