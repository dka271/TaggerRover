/*******************************************************************************
  I2C Device Driver Definition

  Company:
    Microchip Technology Inc.

  File Name:
    drv_i2c.c

  Summary:
    I2C Device Driver Dynamic Multiple Client Implementation

  Description:
    The I2C device driver provides a simple interface to manage the I2C
    modules on Microchip microcontrollers.  This file Implements the core
    interface routines for the I2C driver.

    While building the driver from source, ALWAYS use this file in the build.
*******************************************************************************/

//DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2012 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*******************************************************************************/
//DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Include Files
// *****************************************************************************
// *****************************************************************************

#include "driver/i2c/src/drv_i2c_local.h"
#include "osal/osal.h"

bool _DRV_I2C_IsQueueEmpty(DRV_I2C_OBJ *dObj);
DRV_I2C_BUFFER_OBJECT* _DRV_I2C_QueueSlotGet ( DRV_I2C_OBJ *dObj );


/* this code is included for generating STOP condition using BIT-BANG method */

#if defined  __PIC32MZ &&  (__PIC32_FEATURE_SET0 == 'E') && (__PIC32_FEATURE_SET1 == 'C')
    #ifdef MZ_EC_ERRATA_25_BB_STOP                
        static uint32_t ReadCoreTimer(void);

        static uint32_t ReadCoreTimer()
        {
            volatile uint32_t timer;

            // get the count reg
            asm volatile("mfc0   %0, $9" : "=r"(timer));

            return(timer);
        }

        uint32_t    starttime;

        #define BAUD_RATE_0         50000
        #define BRG_1_TIME_0        SYS_CLK_PeripheralFrequencyGet(CLK_BUS_PERIPHERAL_2)/(2*BAUD_RATE_0)
    #endif
#endif

// *****************************************************************************
// *****************************************************************************
// Section: File Scope Variables
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Driver Hardware instance objects.

  Summary:
    Defines the hardware instances objects that are available on the part

  Description:
    This data type defines the hardware instance objects that are available on
    the part, so as to capture the hardware state of the instance.

  Remarks:
    Not all modes are available on all micro-controllers.
*/

static DRV_I2C_OBJ             gDrvI2CObj[DRV_I2C_INSTANCES_NUMBER] ;

// *****************************************************************************
/* Driver Client instance objects.

  Summary:
    Defines the Client instances objects that are available on the part

  Description:
    This data type defines the Client instance objects that are available on
    the part, so as to capture the Client state of the instance.

  Remarks:
    None
*/

static DRV_I2C_CLIENT_OBJ      gDrvI2CClientObj [ DRV_I2C_CLIENTS_NUMBER ] ;


// *****************************************************************************
/* Driver data objects.

  Summary:
    Defines the data object.

  Description:
    This data type defines the data objects. This is used to queue the user
    requests for different operations.

  Remarks:
    None
*/

static DRV_I2C_BUFFER_OBJECT	gDrvI2CBufferObj [ DRV_I2C_INSTANCES_NUMBER ][ DRV_I2C_NUM_OF_BUFFER_OBJECTS ];


/* This object maintains data that is required by all USART
   driver instances. */
DRV_I2C_COMMON_DATA_OBJ gDrvI2CCommonDataObj;

// *****************************************************************************
/* Driver Shared Object protection
 */
static uint32_t i2cNumInited = 0;

//static OSAL_MUTEX_DECLARE(i2cClientMutex);

// *****************************************************************************
/* Macro: _DRV_I2C_CLIENT_OBJ(obj,mem)

  Summary:
    Returns the appropriate client member

  Description:
    Either return the static object or returns the indexed dynamic object.
    This macro has variations for dynamic or static driver.
*/

#define _DRV_I2C_CLIENT_OBJ(obj,mem)    obj->mem


// *****************************************************************************
/* Macro: _DRV_I2C_CLIENT_OBJ_GET(obj)

  Summary:
    Returns the appropriate client instance

  Description:
    Either return the static object or returns the indexed dynamic object.
    This macro has variations for dynamic or static driver.
*/

#define _DRV_I2C_CLIENT_OBJ_GET(obj)    &gDrvI2CClientObj[obj]

// *****************************************************************************
/* Macro: _DRV_I2C_DATA_OBJ(obj,mem)

  Summary:
    Returns the appropriate client member

  Description:
    Either return the static object or returns the indexed dynamic object.
    This macro has variations for dynamic or static driver.
*/

#define _DRV_I2C_DATA_OBJ(obj,mem)    ((DRV_I2C_BUFFER_OBJECT*)(obj))->mem

// *****************************************************************************
/*
 Upper address limit for a 7-bit address 
 */

#define ADDRESS_7BIT_UPPER_LIMIT                    0xFF

// *****************************************************************************
// *****************************************************************************
// Section: File Scope Functions
// *****************************************************************************
// *****************************************************************************

static void _DRV_I2C_LockMutex(DRV_I2C_OBJ *dObj);
static void _DRV_I2C_UnlockMutex(DRV_I2C_OBJ *dObj);
static void _DRV_I2C_SetupHardware ( const I2C_MODULE_ID plibId,
                                     DRV_I2C_OBJ *dObj,
                                     DRV_I2C_INIT * i2cInit );

// *****************************************************************************
/* Function:
    DRV_I2C_BUFFER_OBJ* _DRV_I2C_QueueSlotGet ( DRV_I2C_OBJ *dObj )

  Summary:
    Adds an element to the queue.

  Description:
    This API adds an element to the queue.

  Parameters:
    i2cDataObj   - Pointer to the structure which holds the data which is to be
    				added to the queue.

  Returns:
    DRV_I2C_BUFFER_HANDLE - Handle, a pointer to the allocated element in the
    						queue.
*/
DRV_I2C_BUFFER_OBJECT* _DRV_I2C_QueueSlotGet ( DRV_I2C_OBJ *dObj )
{
    uint8_t numOfFreeQueueSlots;
    DRV_I2C_BUFFER_OBJECT *lQueueObj;
    bool interruptEnableState = false;
    
    SYS_MODULE_INDEX drvIndex = dObj->drvIndex;
    
    if (dObj->interruptNestingCount == 0)
    {
        Nop();
        if (OSAL_MUTEX_Lock(&(dObj->mutexDriverInstance), OSAL_WAIT_FOREVER)  == OSAL_RESULT_TRUE) 
        {
            /* We will disable interrupts so that the queue
               status does not get updated asynchronously.
               This code will always execute. */
            
            if (dObj->i2cMode == DRV_I2C_MODE_MASTER)
            {
                interruptEnableState = _DRV_I2C_InterruptSourceDisable(dObj->mstrInterruptSource);
            }
            else
            {
                interruptEnableState = _DRV_I2C_InterruptSourceDisable(dObj->slaveInterruptSource);
            }
        }
        else
        {
            /* The mutex acquisition timed out. Return with an
               invalid handle. This code will not execute
               if there is no RTOS. */
            return (DRV_I2C_BUFFER_OBJECT*)NULL;;
            
        }
    }
    
//    _DRV_I2C_LockMutex(dObj);
    
    /* if position of item populated in the queue (Queue-In pointer) is greater 
     * than the position where the item is to be taken out of the queue,
     * (Queue-Out pointer) then the number of free slots is the remainder of the 
     * slots excluding the slot index where Queue Out pointer resides to the 
     * slot index where Queue-In pointer resides.
     * Ex: # of Queue Slots = 6, Queue-In = 5 and Queue-Out = 2
     * Number of free queue available  = 6 -(5-2) - 1 = 2 (free slots - 6 & 1)
     * 
     * if Queue-Out pointer is greater than Queue-In pointer but the Queue Out 
     * pointer is adjacent to Queue-In pointer (Queue-Out - Queue-In == 1) 
     * then buffer is full. Return 0 slots available if it's the case.      
     * If Queue-Out pointer is greater than Queue-In pointer then slots starting
     * from Queue-In pointer to Queue-Out pointer is number of available queue
     * slots 
     * Ex: # of Queue Slots = 6, Queue-Out = 4 and Queue-In = 2
     * Number of free queue slots available  = 4-2-1 (free slots - 3)
     */
    
    if (dObj->queueIn >= dObj->queueOut)
    {
        numOfFreeQueueSlots =  (DRV_I2C_NUM_OF_BUFFER_OBJECTS - (dObj->queueIn - dObj->queueOut) -1);
    }
    else 
    {
        numOfFreeQueueSlots = ((dObj->queueOut - dObj->queueIn) -1);   
    }
    
    if (numOfFreeQueueSlots > 0)
    {
        lQueueObj = &gDrvI2CBufferObj [ drvIndex ][ dObj->queueIn ];
        
        dObj->queueIn++;
        
        if ( dObj->queueIn >= DRV_I2C_NUM_OF_BUFFER_OBJECTS )
        {
            dObj->queueIn = 0;
        }
        
        /* We are done. Restore the interrupt enable status
           and return. */

        if(interruptEnableState)
        {
            if (dObj->i2cMode == DRV_I2C_MODE_MASTER)
            {
                _DRV_I2C_InterruptSourceEnable(dObj->mstrInterruptSource);
            }
            else
            {
                 _DRV_I2C_InterruptSourceEnable(dObj->slaveInterruptSource);
            }
        }
        
        if(dObj->interruptNestingCount == 0)
        {
            /* Release mutex */
            OSAL_MUTEX_Unlock(&(dObj->mutexDriverInstance));
        }
                
//        _DRV_I2C_UnlockMutex(dObj);
        return lQueueObj;
    }
    
    if(interruptEnableState)
    {
        if (dObj->i2cMode == DRV_I2C_MODE_MASTER)
        {
            _DRV_I2C_InterruptSourceEnable(dObj->mstrInterruptSource);
        }
        else
        {
             _DRV_I2C_InterruptSourceEnable(dObj->slaveInterruptSource);
        }
    }

    if(dObj->interruptNestingCount == 0)
    {
        /* Release mutex */
        OSAL_MUTEX_Unlock(&(dObj->mutexDriverInstance));
    }       

   return (DRV_I2C_BUFFER_OBJECT*)NULL;
}

DRV_I2C_BUFFER_OBJECT* _DRV_I2C_QueueTailReset ( SYS_MODULE_INDEX drvIndex )
{
    
    DRV_I2C_BUFFER_OBJECT *lQueueObj;
    
    lQueueObj = &gDrvI2CBufferObj [ drvIndex ][ 0 ];
    
    return lQueueObj;
}


// *****************************************************************************
/* Function:
    DRV_I2C_BUFFER_OBJ* _DRV_I2C_QueuePop ( DRV_I2C_OBJ *dObj )

  Summary:
    Removes a element from the queue

  Description:
    This API removes an element from the queue

  Parameters:
    i2cDataObj   - Pointer to the data structure to be removed from the queue

  Returns:
    DRV_I2C_BUFFER_HANDLE - Handle, a pointer to the next allocated element in the
    						queue.
*/

DRV_I2C_BUFFER_OBJECT * _DRV_I2C_QueuePop( DRV_I2C_OBJ *dObj)
{
    SYS_MODULE_INDEX drvIndex = dObj->drvIndex;
    
    // Make sure that the pointer is valid inside out allocated space.
    if (dObj < &gDrvI2CObj[0] || dObj > &gDrvI2CObj[DRV_I2C_INSTANCES_NUMBER-1])
    {
            return NULL;
    }
    // Make sure that this driver instance is actually in use.
    if (dObj->inUse != true)
    {
            return NULL;
    }
        
    DRV_I2C_BUFFER_OBJECT * ret = &gDrvI2CBufferObj [ drvIndex ][ dObj->queueOut ];
    
    if (dObj->i2cMode == DRV_I2C_MODE_SLAVE )
    {
        if ( dObj->queueOut >= (DRV_I2C_NUM_OF_BUFFER_OBJECTS-1) )
        {
            dObj->queueOut = 0;
        }
        else
        {
            dObj->queueOut++;
        }
    }
           
    return ret;
}


void _DRV_I2C_Advance_Queue( DRV_I2C_OBJ *dObj )
{
    
    if (dObj->i2cMode == DRV_I2C_MODE_MASTER)
    {
        if ( dObj->queueOut >= (DRV_I2C_NUM_OF_BUFFER_OBJECTS-1) )
        {
            dObj->queueOut = 0;
        }
        else
        {
            dObj->queueOut++;
        }
    }
}

// *****************************************************************************
/* Function:
    DRV_I2C_BUFFER_OBJ* _DRV_I2C_IsQueueEmpty (DRV_I2C_OBJ *dObj)

  Summary:
    Checks if the queue is empty

  Description:
    This API checks if the end of queue has been reached or if the tail pointer
    is at the same location as the head pointer. If the tail pointer and head
    pointer coincide, it implies that the queue is empty

  Parameters:
    i2cDataObj   - Pointer to the data structure to be removed from the queue
    i2cbufferObj - Pointer to buffer where i2c objects are stored
  Returns:
    None
*/

bool _DRV_I2C_IsQueueEmpty(DRV_I2C_OBJ *dObj)
{
    
//    DRV_I2C_BUFFER_OBJECT * temp;
    // Make sure that the pointer is valid inside out allocated space.
    if (dObj < &gDrvI2CObj[0] || dObj > &gDrvI2CObj[DRV_I2C_INSTANCES_NUMBER-1])
    {
        return false;
    }
    // Make sure that this driver instance is actually in use.
    if (dObj->inUse != true)
    {
        return false;
    }
    
    
    if (dObj->queueOut == dObj->queueIn)
        return true;
    
    return false;
    

}

// *****************************************************************************
/* Function:
    DRV_I2C_BUFFER_OBJ* _DRV_I2C_QueuePush (DRV_I2C_OBJ *dObj, DRV_I2C_BUFFER_OBJECT *buf)

  Summary:
 Adds a DRV_I2C_OBJ into a I2C Buffer Object

  Description:
    This API adds an DRV_I2C_OBJ into a buffer containing I2C objects

  Parameters:
    i2cDataObj   - Pointer to the data structure to be removed from the queue
    i2cbufferObj - Pointer to buffer where i2c objects are stored
  Returns:
    None
*/

void _DRV_I2C_QueuePush(DRV_I2C_OBJ *dObj, DRV_I2C_BUFFER_OBJECT *buf)
{
    
    SYS_MODULE_INDEX drvIndex=(SYS_MODULE_INDEX)0;
    
    // Make sure that the pointer is valid inside out allocated space.
    if (dObj < &gDrvI2CObj[0] || dObj > &gDrvI2CObj[DRV_I2C_INSTANCES_NUMBER-1])
    {
	return;
    }
    // Make sure that this driver instance is actually in use.
    if (dObj->inUse != true)
    {
    	return;
    }

    drvIndex = dObj->drvIndex;
    if (buf < &gDrvI2CBufferObj[drvIndex][0] || buf > &gDrvI2CBufferObj[drvIndex][DRV_I2C_NUM_OF_BUFFER_OBJECTS])
    {
    	return;
    }

    dObj->queueHead = &gDrvI2CBufferObj[drvIndex][dObj->queueIn];
    return;
}


//******************************************************************************
/* Function:
    static void _DRV_I2C_SetupHardware ( const I2C_MODULE_ID   plibId,
                                        DRV_I2C_OBJ_HANDLE     dObj,
                                        DRV_I2C_INIT         * i2cInit )

  Summary:
    Sets up the hardware from the initialization structure

  Description:
    This routine sets up the hardware from the initialization structure.

  Remarks:
    None.
*/

static void _DRV_I2C_SetupHardware ( const I2C_MODULE_ID plibId,
                                     DRV_I2C_OBJ *dObj,
                                     DRV_I2C_INIT * i2cInit )
{
    /* Initialize the Interrupt Sources */
    dObj->mstrInterruptSource   = i2cInit->mstrInterruptSource;
    dObj->slaveInterruptSource  = i2cInit->slaveInterruptSource;
    dObj->errInterruptSource    = i2cInit->errInterruptSource;

    /* Power state initialization */
    if( _DRV_I2C_POWER_STATE_GET( i2cInit->moduleInit.value ) == SYS_MODULE_POWER_IDLE_STOP )
    {
        PLIB_I2C_StopInIdleEnable( plibId  );
    }
    else if( ( _DRV_I2C_POWER_STATE_GET( i2cInit->moduleInit.value ) == SYS_MODULE_POWER_IDLE_RUN ) ||
                ( _DRV_I2C_POWER_STATE_GET( i2cInit->moduleInit.value ) == SYS_MODULE_POWER_RUN_FULL ) )
    {
        PLIB_I2C_StopInIdleDisable( plibId  );
    }
    else
    {
        if( _DRV_I2C_POWER_STATE_GET( i2cInit->moduleInit.sys.powerState ) == SYS_MODULE_POWER_IDLE_STOP )
        {
            PLIB_I2C_StopInIdleEnable( plibId  );
        }
    }

     /* Set I2C operational mode -- Master or Slave */
     dObj->i2cMode = _DRV_I2C_OPERATION_MODE_GET(i2cInit->i2cMode);

     /* Set Baud Rate */
     if ( DRV_I2C_MODE_MASTER == _DRV_I2C_OPERATION_MODE_GET(i2cInit->i2cMode))
     {
        PLIB_I2C_BaudRateSet ( plibId, SYS_CLK_PeripheralFrequencyGet(CLK_BUS_PERIPHERAL_1),
                                _DRV_I2C_BAUD_RATE_VALUE_GET(i2cInit->baudRate) );
        dObj->modulemainstate = DRV_I2C_MODULE_IDLE;
     }

     /* Set SLEW rate based on baud-rate; if baud-rate is either <= 100k
        OR baud-rate = 1M; I2C2xCON.DISSLW = 1  */
    if (_DRV_I2C_BAUD_RATE_VALUE_GET(i2cInit->baudRate) <= 100000 ||
            _DRV_I2C_BAUD_RATE_VALUE_GET(i2cInit->baudRate) == 1000000 )
    {
        PLIB_I2C_HighFrequencyEnable(plibId);
    }
     else
    {
        PLIB_I2C_HighFrequencyDisable(plibId);
    }

    /* SMBus Input Level */
    dObj->buslevel = _DRV_I2C_SMBus_LEVEL_GET(i2cInit->buslevel);

    /* Slave Address width select */
    if ( DRV_I2C_MODE_SLAVE == _DRV_I2C_OPERATION_MODE_GET(i2cInit->i2cMode))
    {
        dObj->modulemainstate = DRV_I2C_MODULE_IDLE;

        if (DRV_I2C_7BIT_SLAVE == _DRV_I2C_ADDRESS_WIDTH_GET(i2cInit->addWidth))
            PLIB_I2C_SlaveAddress7BitSet(plibId, (I2C_SLAVE_ADDRESS_7bit)(i2cInit->slaveaddvalue>>1));
        else
            PLIB_I2C_SlaveAddress10BitSet (plibId,(i2cInit->slaveaddvalue>>1) );

        PLIB_I2C_SlaveClockStretchingEnable(plibId);
        PLIB_I2C_ReservedAddressProtectEnable(plibId);
        PLIB_I2C_GeneralCallDisable ( plibId );
        PLIB_I2C_ReservedAddressProtectEnable(plibId);
        PLIB_I2C_SlaveMask7BitSet ( plibId, i2cInit->maskslaveaddress );
        _DRV_I2C_InterruptSourceEnable( dObj->slaveInterruptSource ) ;
        SYS_INT_SourceStatusClear(dObj->slaveInterruptSource);
    }

    /* Allow reserved slave address */
     dObj->reservedaddenable = _DRV_I2C_RESERVED_ADDRESS_EN_GET(i2cInit->reservedaddenable);

} /* _DRV_I2C_SetupHardware */

//******************************************************************************
/* Function:
    static void _DRV_I2C_LockMutex(DRV_I2C_OBJ *dObj)

 Summary:
    Invokes OSAL call

 Parameters:
    i2cDataObj   - Pointer to the structure which holds the data which is to be
    				added to the queue.

  Remarks:
    None.
*/

void _DRV_I2C_LockMutex(DRV_I2C_OBJ *dObj)
{
    bool tmp = false;
    tmp = tmp; // Remove compile warning 
    Nop();
    if (OSAL_MUTEX_Lock(&dObj->mutexDriverInstance, OSAL_WAIT_FOREVER)  != OSAL_RESULT_TRUE) {/* Report error*/}
} /*    _DRV_I2C_LockMutex  */

//******************************************************************************
/* Function:
    static void _DRV_I2C_UnlockMutex(DRV_I2C_OBJ *dObj)

 Summary:
    Invokes OSAL call

 Parameters:
    i2cDataObj   - Pointer to the structure which holds the data which is to be
    				added to the queue.

  Remarks:
    None.
*/

void _DRV_I2C_UnlockMutex(DRV_I2C_OBJ *dObj)
{
    bool tmp = false;
    tmp = tmp; // Remove compile warning
    if (OSAL_MUTEX_Unlock(&dObj->mutexDriverInstance)  != OSAL_RESULT_TRUE) {/* Report error*/}
} /* _DRV_I2C_UnlockMutex */


// *****************************************************************************
// *****************************************************************************
// Section: Driver Interface Function Definitions
// *****************************************************************************
// *****************************************************************************

//******************************************************************************
/* Function:
    SYS_MODULE_OBJ DRV_I2C_Initialize ( const SYS_MODULE_INDEX  index,
                                       const SYS_MODULE_INIT * const init )

  Summary:
    Initializes hardware and data for the given instance of the I2C module

  Description:
    This routine initializes hardware for the instance of the I2C module,
    using the hardware initialization given data.  It also initializes all
    necessary internal data.

  Parameters:
    index           - Identifies the driver instance to be initialized

    init            - Pointer to the data structure containing all data
                      necessary to initialize the hardware. This pointer may
                      be null if no data is required and static initialization
                      values are to be used.

  Returns:
    If successful, returns a valid handle to a driver instance object.
    Otherwise, it returns SYS_MODULE_OBJ_INVALID.
*/

SYS_MODULE_OBJ DRV_I2C_Initialize ( const SYS_MODULE_INDEX   drvIndex,
                                   const SYS_MODULE_INIT    * const init )
{
    DRV_I2C_INIT * i2cInit;
    I2C_MODULE_ID i2cId;
    
    uint16_t index;
    DRV_I2C_BUFFER_OBJECT   *lBufferObj;

    /* Validate the driver index */
    if ( drvIndex >= DRV_I2C_INSTANCES_NUMBER )
    {
        return SYS_MODULE_OBJ_INVALID;
    }
    DRV_I2C_OBJ *dObj = _DRV_I2C_INSTANCE_GET ( drvIndex );

    /* Cheap dead man's mutex during initialization to make sure two different
       tasks don't try to initialize the same driver at the same time.*/

    if (dObj->inUse)
    {
        return SYS_MODULE_OBJ_INVALID;
    }

    if (i2cNumInited == 0)
    {
        memset(gDrvI2CClientObj, 0, sizeof(gDrvI2CClientObj));
    }

    i2cNumInited++;

    /* Assign to the local pointer the init data passed */
    i2cInit = ( DRV_I2C_INIT * ) init;

    /* Object is valid, set it in use */
    dObj->inUse = true;

    /* Save the index of the driver. Important to know this
    as we are using reference based accessing */
    dObj->drvIndex = drvIndex;

    /* Update the I2C Module Index */
    dObj->i2cId = i2cInit->i2cId;
    
    /* set QueueHead to NULL */
    dObj->queueHead = NULL;
    
    /* initialize QueueTail to NULL */
    dObj->queueTail = NULL;
    
    dObj->queueIn = 0;
    
    dObj->queueOut = 0;
    
    /* Speed up accessing, take it to a local variable */
    i2cId = dObj->i2cId;

    /* Setup the Hardware */
    _DRV_I2C_SetupHardware ( i2cId, dObj, i2cInit );

    /* Reset the number of clients */
    dObj->numClients = 0;

    /* Reset the locally used variables */
    dObj->lastClientHandle  = DRV_I2C_CLIENTS_NUMBER+1;

    dObj->operationStarting = i2cInit->operationStarting;
    
    
    for ( index=0; index<DRV_I2C_NUM_OF_BUFFER_OBJECTS; index++ )
    {
        lBufferObj = &gDrvI2CBufferObj [ drvIndex ][ index ];

        lBufferObj->inUse   = false;
        lBufferObj->next    = NULL;
    }

    /* Interrupt flag cleared on the safer side */

    _DRV_I2C_InterruptSourceClear( dObj->mstrInterruptSource );
    _DRV_I2C_InterruptSourceClear( dObj->slaveInterruptSource );
    _DRV_I2C_InterruptSourceClear( dObj->errInterruptSource );

    /* Set the current driver state */
    dObj->status = SYS_STATUS_READY;
    
    dObj->interruptNestingCount = 0;

        /* Create the hardware instance mutex. */
    if(OSAL_MUTEX_Create(&(dObj->mutexDriverInstance)) != OSAL_RESULT_TRUE)
    {
       return SYS_MODULE_OBJ_INVALID;
    }
    
        /* Check if the global mutexes have been created. If not
       then create these. */

    if(!gDrvI2CCommonDataObj.membersAreInitialized)
    {
        /* This means that mutexes where not created. Create them. */
        if(OSAL_MUTEX_Create(&(gDrvI2CCommonDataObj.mutexClientObjects)) != OSAL_RESULT_TRUE)
        {
                 return SYS_MODULE_OBJ_INVALID;
        }
        if(OSAL_MUTEX_Create(&(gDrvI2CCommonDataObj.mutexBufferQueueObjects)) != OSAL_RESULT_TRUE)
        {
                 return SYS_MODULE_OBJ_INVALID;
        }
        /* Set this flag so that global mutexes get allocated only once */
        gDrvI2CCommonDataObj.membersAreInitialized = true;
    }
        
    /* Enable the I2C module */
    PLIB_I2C_Enable( i2cId ) ;
    
    
        /* if device used is PIC32MZ-EC*/
    #if defined  __PIC32MZ &&  (__PIC32_FEATURE_SET0 == 'E') && (__PIC32_FEATURE_SET1 == 'C')
    /*   Errata for PIC32MZ where STOP condition is Bit-banged */
        #ifdef MZ_EC_ERRATA_25_BB_STOP               //GJV
            if (i2cInit->i2cMode == DRV_I2C_MODE_MASTER)
            {
                /* assign SCL and SDA ports for bit banging purposes*/
                dObj->portSCL   = i2cInit->portSCL;
                dObj->pinSCL    = i2cInit->pinSCL;
                dObj->portSDA   = i2cInit->portSDA;
                dObj->pinSDA    = i2cInit->pinSDA;
                
                /* set SDA to 0 */
                PLIB_PORTS_PinClear(PORTS_ID_0, dObj->portSDA, dObj->pinSDA);
                /* set SCL to 1 */
                PLIB_PORTS_PinSet(PORTS_ID_0, dObj->portSCL, dObj->pinSCL);
                /* set SDA to O/P */
                PLIB_PORTS_PinDirectionOutputSet(PORTS_ID_0, dObj->portSDA, dObj->pinSDA);
                /* set SCL to I/P */
                PLIB_PORTS_PinDirectionInputSet(PORTS_ID_0, dObj->portSCL, dObj->pinSCL);
            }
        #endif
    #endif

    /* Return the driver handle */
    return( (SYS_MODULE_OBJ) dObj );
} /* DRV_I2C_Initialize */


//******************************************************************************
/* Function:
    void DRV_I2C_Deinitialize ( SYS_MODULE_OBJ object )

  Summary:
    De-initializes the specific module instance of the I2C module

  Description:
    De-initializes the specific module instance disabling its operation (and any
    hardware for driver modules).  Resets all the internal data structures and
    fields for the specified instance to the default settings.

  Parameters:
    object          - Identifies the Driver Object returned by the Initialize
                      interface

  Returns:
    None
*/

void DRV_I2C_Deinitialize ( SYS_MODULE_OBJ object )
{
	DRV_I2C_OBJ *dObj = (DRV_I2C_OBJ*) object;
	I2C_MODULE_ID i2cId = dObj->i2cId;
	size_t iClient;
	uint8_t iDriver;
	if (dObj->inUse == false)
	{
		return;
	}

	/* Interrupt De-Registration */
#if defined (DRV_I2C_INTERRUPT_MODE) && (DRV_I2C_INTERRUPT_MODE == true)
     if (dObj->mstrInterruptEnabled) _DRV_I2C_InterruptSourceDisable(dObj->mstrInterruptSource);
     if (dObj->slaveInterruptEnabled) _DRV_I2C_InterruptSourceDisable(dObj->slaveInterruptSource);
     if (dObj->errInterruptEnabled) _DRV_I2C_InterruptSourceDisable(dObj->errInterruptSource);
#endif

    PLIB_I2C_Disable(i2cId);
    /* Delete the hardware instance mutex. */
    if(OSAL_MUTEX_Delete(&(dObj->mutexDriverInstance)) != OSAL_RESULT_TRUE)
    {
       return;
    }
    
    /* Check if the global mutexes have been created. If so
       then delete these. */
    if(gDrvI2CCommonDataObj.membersAreInitialized)
    {
        /* This means that mutexes where created. Delete them. */
        if(OSAL_MUTEX_Delete(&(gDrvI2CCommonDataObj.mutexClientObjects)) != OSAL_RESULT_TRUE)
        {
                 return;
        }
        if(OSAL_MUTEX_Delete(&(gDrvI2CCommonDataObj.mutexBufferQueueObjects)) != OSAL_RESULT_TRUE)
        {
                 return;
        }
        /* Set this flag so that global mutexes get allocated only once */
        gDrvI2CCommonDataObj.membersAreInitialized = false;
    }
        

	for (iClient = 0; iClient < DRV_I2C_CLIENTS_NUMBER; iClient++)
	{
        if (gDrvI2CClientObj[iClient].driverObject == dObj)
        {
                gDrvI2CClientObj[iClient].driverObject = NULL;
        }
	}

	dObj->numClients = 0;
	dObj->isExclusive = false;
	/* Clear all the pending requests */
        //while (_DRV_I2C_QueuePop(dObj) != NULL);
    while ((_DRV_I2C_IsQueueEmpty(dObj) == false))        
    {
        _DRV_I2C_Advance_Queue(dObj);
    }
    
	dObj->queueHead = NULL;
	/* Set the Device Status */
	dObj->status = SYS_STATUS_UNINITIALIZED;

	/* Remove the driver usage */
	dObj->inUse = false;

	for (iDriver = 0; iDriver < DRV_I2C_INSTANCES_NUMBER; iDriver++)
	{
        DRV_I2C_OBJ * obj = _DRV_I2C_INSTANCE_GET ( iDriver );

        if (obj->inUse == true)
        {
            return;
        }
	}
    i2cNumInited--;

    return;

} /* DRV_I2C_Deinitialize */


//******************************************************************************
/* Function:
    SYS_STATUS DRV_I2C_Status ( SYS_MODULE_OBJ object )

  Summary:
    Provides the current status of the hardware instance of the I2C module

  Description:
    This routine Provides the current status of the hardware instance of the
    I2C module.

  Parameters:
    object          - Identifies the Driver Object returned by the Initialize
                      interface

  Returns:
    SYS_STATUS_READY    Indicates that any previous module operation for the
                        specified module has completed

    SYS_STATUS_BUSY     Indicates that a previous module operation for the
                        specified module has not yet completed

    SYS_STATUS_ERROR    Indicates that the specified module is in an error state
*/

SYS_STATUS DRV_I2C_Status ( SYS_MODULE_OBJ object )
{
    if ( object == SYS_MODULE_OBJ_INVALID )
    {
        //SYS_ASSERT( " Handle is invalid " );
        return SYS_MODULE_OBJ_INVALID;
    }
    DRV_I2C_OBJ *dObj = (DRV_I2C_OBJ*) object;

    /* Return the status associated with the driver handle */
    return ( dObj->status );
} /* DRV_I2C_Status */


//******************************************************************************
/* Function:
    void DRV_I2C_Tasks ( SYS_MODULE_OBJ object )

  Summary:
    Used to maintain the driver's state machine and implement its ISR

  Description:
    This routine is used to maintain the driver's internal state machine and
    implement its ISR for interrupt-driven implementations.

  Parameters:
    object          - Identifies the Driver Object returned by the Initialize
                      interface

  Returns:
    None.
*/

void DRV_I2C_Tasks ( SYS_MODULE_OBJ object )
{

    DRV_I2C_OBJ             *dObj           = (DRV_I2C_OBJ*)object;
    DRV_I2C_BUFFER_OBJECT   *lBufferObj     = dObj->taskLObj;
    I2C_MODULE_ID           i2cId           = dObj->i2cId;

    if ( object == SYS_MODULE_OBJ_INVALID )
    {
        //SYS_ASSERT( " Handle is invalid " );
        return;
    }
    
        switch ( dObj->task )
        {
            case DRV_I2C_TASK_SEND_DEVICE_ADDRESS:

                /* Pop the first element from the queue */
                if ( (_DRV_I2C_OPERATION_MODE_GET(dObj->i2cMode)) == DRV_I2C_MODE_MASTER)
                {
                      if ( ( dObj->queueHead != NULL ) )
                      {
                        /* This should be a global variable since the control could
                        go out of this function */
                        dObj->taskLObj = _DRV_I2C_QueuePop(dObj);

                        /* Take it to a local variable to avoid multiple referencing and to speed up */
                        lBufferObj   = dObj->taskLObj;
                                            
                        
                        if ( lBufferObj->operation == DRV_I2C_OP_READ )
                        {
                                                        
                            PLIB_I2C_TransmitterByteSend( i2cId,(DRV_I2C_OP_READ | lBufferObj->slaveaddresshighbyte) );
                            
                            /* if it is a 10-bit address, then only MSB of the
                             * address needs to be send unlike a write; Thus for
                             * reads 7-bit and 10-bit follows the same logic
                             */
                            _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = DRV_I2C_BUFFER_SLAVE_READ_REQUESTED;
                            
                            dObj->modulemainstate = DRV_I2C_MASTER_RX_FROM_SLAVE;
                            dObj->task = DRV_I2C_TASK_SET_RCEN_ONLY;
                        }
                        else
                        {
                               
                            PLIB_I2C_TransmitterByteSend ( i2cId, lBufferObj->slaveaddresshighbyte ) ;
                            
                            /* if it is a 10-bit address, then subsequent state 
                             * will send the next byte of the address.
                             * Otherwise state is set to write data
                             */
                            
                            if (lBufferObj->slaveaddresslowbyte)
                            {
                                dObj->task = DRV_I2C_SEND_DEVICE_ADDRESS_BYTE_2;
                            }
                            else
                            {
                                _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = DRV_I2C_BUFFER_SLAVE_WRITE_REQUESTED;  
                                  
                                dObj->task = lBufferObj->operation + DRV_I2C_TASK_PROCESS_WRITE_ONLY;
                            }
                        }
                    }
                }
                else if ( (_DRV_I2C_OPERATION_MODE_GET(dObj->i2cMode)) == DRV_I2C_MODE_SLAVE)
                {
                    /* master writing data to slave when R/W = 0 and Address is detected */
                    dObj->task = DRV_I2C_TASK_SEND_DEVICE_ADDRESS;

                    /* Slave is accepting data from Master */
                    if ( (!PLIB_I2C_SlaveReadIsRequested(i2cId)) && (PLIB_I2C_SlaveAddressIsDetected(i2cId)) )
                    {
                        /* slave is set to accept data from master */
                        dObj->modulemainstate = DRV_I2C_SLAVE_READY_TO_RX_FROM_MASTER;

                        if (lBufferObj)
                        {
                            lBufferObj->inUse = false;
                        }

                        if (dObj->operationStarting)
                        {
                            dObj->operationStarting(DRV_I2C_BUFFER_SLAVE_READ_REQUESTED, 0);
                        }

                        /* This should be a global variable since the control could
                            go out of this function */
                        dObj->taskLObj = _DRV_I2C_QueuePop(dObj);

                        /* Take it to a local variable to avoid multiple referencing and to speed up */
                        lBufferObj   = dObj->taskLObj;

                        lBufferObj->actualtransfersize = 0;

                        /* do a dummy read so that I2CxRCV is cleared and not clobbered with data */
                        PLIB_I2C_ReceivedByteGet (i2cId);
                        PLIB_I2C_SlaveClockRelease (i2cId);
                    }
                    /*  Slave is sending data back to the Master    */
                    else if ( (PLIB_I2C_SlaveReadIsRequested(i2cId)) && (PLIB_I2C_SlaveAddressIsDetected(i2cId)) )
                    {

                        PLIB_I2C_ReceivedByteGet ( i2cId );

                        PLIB_I2C_SlaveClockHold (i2cId);

                        dObj->modulemainstate = DRV_I2C_SLAVE_READY_TO_TX_TO_MASTER;

                        if (lBufferObj)
                        {
                            lBufferObj->inUse = false;
                        }

                        if (dObj->operationStarting)
                        {
                            dObj->operationStarting(DRV_I2C_BUFFER_SLAVE_WRITE_REQUESTED, 0);
                        }
                        lBufferObj = dObj->taskLObj = _DRV_I2C_QueuePop(dObj);

                        lBufferObj->actualtransfersize = 0;

                        // transmit first byte
                        PLIB_I2C_TransmitterByteSend(_DRV_I2C_PERIPHERAL_ID_GET(i2cId), *lBufferObj->txBuffer++);
                        lBufferObj->actualtransfersize++;
                        PLIB_I2C_SlaveClockRelease ( i2cId );
                    }
                    else if ( (!PLIB_I2C_SlaveReadIsRequested(i2cId)) && PLIB_I2C_SlaveDataIsDetected( i2cId ))
                    {
                        /*        Master sends data to the slave        */
                        if (dObj->modulemainstate == DRV_I2C_SLAVE_READY_TO_RX_FROM_MASTER)
                        {
                            PLIB_I2C_SlaveClockRelease ( i2cId );

                            if (lBufferObj->actualtransfersize < lBufferObj->transferSize)
                            {
                                *lBufferObj->rxBuffer++ = PLIB_I2C_ReceivedByteGet ( i2cId );
                                lBufferObj->actualtransfersize++;

                                _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = DRV_I2C_BUFFER_SLAVE_READ_BYTE;

                                if ( _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback) != NULL )
                                {
                                    /*  Call the event handler. Increment the interrupt nesting
                                        count which lets the driver functions that are called
                                        from the event handler know that an interrupt context
                                        is active.
                                    */
                                    
                                    dObj->interruptNestingCount++;
                                    
                                    _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle),
                                                callback)( DRV_I2C_BUFFER_SLAVE_READ_BYTE, (DRV_I2C_BUFFER_HANDLE)lBufferObj, 0x00 );
                                    
                                    dObj->interruptNestingCount--;
                                }
                            }
                            else
                            {
                                _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = DRV_I2C_BUFFER_EVENT_ERROR;

                                PLIB_I2C_ReceivedByteGet ( i2cId );

                                if ( _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback) != NULL )
                                {
                                    /*  Call the event handler. Increment the interrupt nesting
                                        count which lets the driver functions that are called
                                        from the event handler know that an interrupt context
                                        is active.
                                    */
                                    
                                    dObj->interruptNestingCount++;
                                    
                                    _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle),
                                                callback)( DRV_I2C_BUFFER_EVENT_ERROR, (DRV_I2C_BUFFER_HANDLE)lBufferObj, 0x00 );
                                    
                                    dObj->interruptNestingCount--;
                                }
                            }
                        }
                    }
                    else if (PLIB_I2C_SlaveReadIsRequested(i2cId) && PLIB_I2C_SlaveDataIsDetected( i2cId ))
                    {
                        PLIB_I2C_SlaveClockHold (i2cId);

                        if ( PLIB_I2C_TransmitterByteWasAcknowledged(i2cId) )
                        {
                            if ( lBufferObj->actualtransfersize < lBufferObj->transferSize )
                            {
                                PLIB_I2C_SlaveClockRelease(i2cId);
                                PLIB_I2C_TransmitterByteSend ( _DRV_I2C_PERIPHERAL_ID_GET ( i2cId ), *lBufferObj->txBuffer++ );
                                lBufferObj->actualtransfersize++;
                                lBufferObj->inUse = false;

                                _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = DRV_I2C_BUFFER_SLAVE_WRITE_BYTE;

                                if ( _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback) != NULL )
                                {
                                    /*  Call the event handler. Increment the interrupt nesting
                                        count which lets the driver functions that are called
                                        from the event handler know that an interrupt context
                                        is active.
                                    */
                                    
                                    dObj->interruptNestingCount++;
                                    
                                    _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle),
                                                callback)( DRV_I2C_BUFFER_SLAVE_WRITE_BYTE, (DRV_I2C_BUFFER_HANDLE)lBufferObj, 0x00 );
                                                                                                            
                                    dObj->interruptNestingCount--;
                                }
                            }
                            else
                            {
                               _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = DRV_I2C_BUFFER_EVENT_ERROR;

                                /* Have a check here because DRV_I2C_ClientSetup function call is optional */
                                if ( _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback) != NULL )
                                {
                                    /*  Call the event handler. Increment the interrupt nesting
                                        count which lets the driver functions that are called
                                        from the event handler know that an interrupt context
                                        is active.
                                    */
                                    
                                    dObj->interruptNestingCount++;
                                    
                                    /* Give an indication to the higher layer upon successful transmission */
                                   _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback)
                                            ( DRV_I2C_BUFFER_EVENT_ERROR, (DRV_I2C_BUFFER_HANDLE)lBufferObj, 0x00 );
                                   
                                    dObj->interruptNestingCount--;
                                }
                                /* dummy write - pad with zeros - cases where master requests more data than what is in buffer */
                                PLIB_I2C_TransmitterByteSend(_DRV_I2C_PERIPHERAL_ID_GET(i2cId), 0);
                            }
                        }
                        else if ( !PLIB_I2C_TransmitterByteWasAcknowledged(i2cId) )
                        {

                           _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = DRV_I2C_BUFFER_EVENT_COMPLETE;

                             /* Have a check here because DRV_I2C_ClientSetup function call is optional */
                            if ( _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback) != NULL )
                            {
                                /*  Call the event handler. Increment the interrupt nesting
                                    count which lets the driver functions that are called
                                    from the event handler know that an interrupt context
                                    is active.
                                */
                                    
                                dObj->interruptNestingCount++;
                                
                                /* Give an indication to the higher layer upon successful transmission */
                                _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback)
                                      ( DRV_I2C_BUFFER_EVENT_COMPLETE, (DRV_I2C_BUFFER_HANDLE)lBufferObj, 0x00 );
                                
                                dObj->interruptNestingCount--;
                            }
                        }
                    }
                }
                break;
            case DRV_I2C_SEND_DEVICE_ADDRESS_BYTE_2:

                if ( lBufferObj->operation == DRV_I2C_OP_READ )
                {                    
                    _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = DRV_I2C_BUFFER_SLAVE_READ_REQUESTED;
                         
                    dObj->modulemainstate = DRV_I2C_MASTER_RX_FROM_SLAVE;
                    PLIB_I2C_TransmitterByteSend( i2cId,lBufferObj->slaveaddresslowbyte>>1) ;
                    dObj->task = DRV_I2C_TASK_SET_RCEN_ONLY;
                }
                else
                {
                    _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = DRV_I2C_BUFFER_SLAVE_WRITE_REQUESTED;
                                                
                    PLIB_I2C_TransmitterByteSend (i2cId, lBufferObj->slaveaddresslowbyte>>1) ;
                    dObj->task = lBufferObj->operation + DRV_I2C_TASK_PROCESS_WRITE_ONLY;
                }
                
                break;
            case DRV_I2C_SEND_RANDOM_READ_DEVICE_ADDRESS:
                    dObj->modulemainstate = DRV_I2C_MASTER_RX_FROM_SLAVE;
                    PLIB_I2C_TransmitterByteSend( i2cId,(DRV_I2C_OP_READ | lBufferObj->slaveaddresshighbyte) );
                    dObj->task = DRV_I2C_TASK_SET_RCEN_ONLY;
                break;             
            case DRV_I2C_TASK_PROCESS_READ_ONLY:
                /* Read I2CxRCV register for received data */
                if ( (_DRV_I2C_OPERATION_MODE_GET(dObj->i2cMode)) == DRV_I2C_MODE_MASTER)
                {
                    if (lBufferObj->transferSize)
                    {
                        dObj->modulemainstate = DRV_I2C_MASTER_RX_FROM_SLAVE;

                        if ( PLIB_I2C_ReceivedByteIsAvailable (i2cId) )
                        {
                            /* If all but one reception is complete */
                            if ( lBufferObj->transferSize > 1 )
                            {
                                *lBufferObj->rxBuffer++ = PLIB_I2C_ReceivedByteGet (i2cId);
                                lBufferObj->transferSize--;
                                lBufferObj->actualtransfersize++;
                                dObj->task = DRV_I2C_TASK_SET_RCEN_ONLY;
                                
                                if (PLIB_I2C_MasterReceiverReadyToAcknowledge(i2cId))
                                {
                                    _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = DRV_I2C_BUFFER_MASTER_ACK_SEND;
                                                                                    
                                    PLIB_I2C_ReceivedByteAcknowledge ( i2cId, true );
                                }
                            }
                            else
                            {
                                lBufferObj->transferSize--;
                                lBufferObj->actualtransfersize++;

                                *lBufferObj->rxBuffer++ = PLIB_I2C_ReceivedByteGet ( i2cId );
                                if (PLIB_I2C_MasterReceiverReadyToAcknowledge(i2cId))
                                {                                    
                                    _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = DRV_I2C_BUFFER_MASTER_NACK_SEND;
                                                                                    
                                    PLIB_I2C_ReceivedByteAcknowledge ( i2cId, false  );
                                }

                                dObj->task = DRV_I2C_BUS_SILENT;
                            }
                        }
                        else
                        {
                            // Do not block in any case
                            break;
                        }
                    }
                }
                break;
            case DRV_I2C_TASK_PROCESS_WRITE_ONLY:
            case DRV_I2C_TASK_PROCESS_WRITE_READ:

                if ( (_DRV_I2C_OPERATION_MODE_GET(dObj->i2cMode)) == DRV_I2C_MODE_MASTER)
                {
                    /* Loop till the transmit size, do not block though */
                    if( lBufferObj->transferSize )
                    {
                        if ( PLIB_I2C_TransmitterByteHasCompleted (_DRV_I2C_PERIPHERAL_ID_GET (i2cId)) )
                        {
                            if ( PLIB_I2C_TransmitterByteWasAcknowledged (_DRV_I2C_PERIPHERAL_ID_GET (i2cId)) ||
                                   (lBufferObj->transmitForced)  )
                            {
                                /* Handle the overflow */
                                if ( lBufferObj->transferSize > 1 )
                                {
                                    lBufferObj->actualtransfersize++;
                                    PLIB_I2C_TransmitterByteSend ( _DRV_I2C_PERIPHERAL_ID_GET ( i2cId ), *lBufferObj->txBuffer++ );
                                    lBufferObj->transferSize--;
                                }
                                else
                                {
                                    lBufferObj->transferSize--;
                                    lBufferObj->actualtransfersize++;
                                    
                                    PLIB_I2C_TransmitterByteSend ( _DRV_I2C_PERIPHERAL_ID_GET ( i2cId ), *lBufferObj->txBuffer++ );

                                    dObj->task = DRV_I2C_BUS_SILENT;

                                }
                            }
                            else
                            {
                                #if defined  __PIC32MZ &&  (__PIC32_FEATURE_SET0 == 'E') && (__PIC32_FEATURE_SET1 == 'C')
                                /*   Errata for PIC32MZ which requires reset of I2C module */
                                         
                                    dObj->task = DRV_I2C_TASK_SEND_DEVICE_ADDRESS;
                                    
                                    /* alternate method to do STOP (previous errata note) */  
                                                                        
                                    #ifdef MZ_EC_ERRATA_25_BB_STOP                
                                        /* Bit bang procedure for STOP */

                                        starttime = ReadCoreTimer();
                                        while(ReadCoreTimer()-starttime < BRG_1_TIME_0);

                                        /* Disable I2C */
                                        PLIB_I2C_Disable(i2cId);

                                        /* Wait 2 BRG */
                                        starttime = ReadCoreTimer();
                                        while(ReadCoreTimer()- starttime < BRG_1_TIME_0);

                                        /* Set SDA as I/P */
                                        PLIB_PORTS_PinDirectionInputSet(PORTS_ID_0, dObj->portSDA, dObj->pinSDA);

                                        /* Wait 3 BRG */
                                        starttime = ReadCoreTimer();
                                        while(ReadCoreTimer()- starttime < BRG_1_TIME_0);

                                        PLIB_I2C_Enable(i2cId);
                                        PLIB_PORTS_PinClear(PORTS_ID_0, dObj->portSDA, dObj->pinSDA);
                                        PLIB_PORTS_PinSet(PORTS_ID_0, dObj->portSCL, dObj->pinSCL);
                                        PLIB_PORTS_PinDirectionOutputSet(PORTS_ID_0, dObj->portSDA, dObj->pinSDA);
                                        PLIB_PORTS_PinDirectionInputSet(PORTS_ID_0, dObj->portSCL, dObj->pinSCL);

                                        /* End-of-Bit-Bang procedure for STOP */
                                    #else                                                    
                                      PLIB_I2C_Disable(i2cId);
                                      PLIB_I2C_Enable(i2cId);
                                    #endif                                                   
                                    
                                    if (lBufferObj)
                                    {
                                        lBufferObj->inUse = false;
                                    }                                                                    

                                    /*clear any previous status flags */
                                    _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = 0;
                                    
                                    /* set status to buffer event complete */
                                    _DRV_I2C_CLIENT_OBJ(lBufferObj, status) |=
                                        DRV_I2C_BUFFER_EVENT_ERROR;

                                    /* Have a check here because DRV_I2C_ClientSetup function call is optional */                       //Issue Callback for STOP event
                                    if ( _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback) != NULL )
                                    {
                                        dObj->interruptNestingCount++;
                                        
                                        /* Give an indication to the higher layer upon successful transmission */
                                        _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback)
                                                ( DRV_I2C_BUFFER_EVENT_ERROR, (DRV_I2C_BUFFER_HANDLE)lBufferObj, 0x00 );
                                        
                                        dObj->interruptNestingCount--;
                                    }
                                #else
                                    dObj->task = DRV_I2C_TASK_PROCESS_STOP;
                                    PLIB_I2C_MasterStop (i2cId);
                                #endif
                            }
                        }
                        else
                        {
                            /* Do not block in any case */
                            break;
                        }
                    }
                    else
                    {
                        #if defined  __PIC32MZ &&  (__PIC32_FEATURE_SET0 == 'E') && (__PIC32_FEATURE_SET1 == 'C')
                        /*   Errata for PIC32MZ which requires reset of I2C module */

                            dObj->task = DRV_I2C_TASK_SEND_DEVICE_ADDRESS;

                            /* alternate method to do STOP (previous errata note) */  

                            #ifdef MZ_EC_ERRATA_25_BB_STOP               //GJV
                                /* Bit bang procedure for STOP */

                                starttime = ReadCoreTimer();
                                while(ReadCoreTimer()-starttime < BRG_1_TIME_0);

                                /* Disable I2C */
                                PLIB_I2C_Disable(i2cId);

                                /* Wait 2 BRG */
                                starttime = ReadCoreTimer();
                                while(ReadCoreTimer()- starttime < BRG_1_TIME_0);

                                /* Set SDA as I/P */
                                PLIB_PORTS_PinDirectionInputSet(PORTS_ID_0, dObj->portSDA, dObj->pinSDA);

                                /* Wait 3 BRG */
                                starttime = ReadCoreTimer();
                                while(ReadCoreTimer()- starttime < BRG_1_TIME_0);

                                PLIB_I2C_Enable(i2cId);
                                PLIB_PORTS_PinClear(PORTS_ID_0, dObj->portSDA, dObj->pinSDA);
                                PLIB_PORTS_PinSet(PORTS_ID_0, dObj->portSCL, dObj->pinSCL);
                                PLIB_PORTS_PinDirectionOutputSet(PORTS_ID_0, dObj->portSDA, dObj->pinSDA);
                                PLIB_PORTS_PinDirectionInputSet(PORTS_ID_0, dObj->portSCL, dObj->pinSCL);

                                /* End-of-Bit-Bang procedure for STOP */
                            #else                                                    
                              PLIB_I2C_Disable(i2cId);
                              PLIB_I2C_Enable(i2cId);
                            #endif                                                   

                            if (lBufferObj)
                            {
                                lBufferObj->inUse = false;
                            }                                                                    

                            /*clear any previous status flags */
                            _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = 0;

                            /* set status to buffer event complete */
                            _DRV_I2C_CLIENT_OBJ(lBufferObj, status) |=
                                DRV_I2C_BUFFER_EVENT_ERROR;

                            /* Have a check here because DRV_I2C_ClientSetup function call is optional */                       //Issue Callback for STOP event
                            if ( _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback) != NULL )
                            {
                                dObj->interruptNestingCount++;
                                
                                /* Give an indication to the higher layer upon successful transmission */
                                _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback)
                                        ( DRV_I2C_BUFFER_EVENT_ERROR, (DRV_I2C_BUFFER_HANDLE)lBufferObj, 0x00 );
                                
                                dObj->interruptNestingCount--;
                            }
                        #else
                            dObj->task = DRV_I2C_TASK_PROCESS_STOP;
                            PLIB_I2C_MasterStop (i2cId);
                        #endif
                    }
                }
                break;
            case DRV_I2C_BUS_SILENT:

                /*  The Bus is Silent/Idle when the last byte is either ACK'ed  OR
                    in the event of slave unexpectedly aborting operation, check
                    if transmission is complete and NACK is received   */

                if ( PLIB_I2C_TransmitterByteWasAcknowledged ( _DRV_I2C_PERIPHERAL_ID_GET ( i2cId ) ) ||
                      ( PLIB_I2C_TransmitterByteHasCompleted ( _DRV_I2C_PERIPHERAL_ID_GET ( i2cId ) )  &&
                            (!PLIB_I2C_TransmitterByteWasAcknowledged ( _DRV_I2C_PERIPHERAL_ID_GET ( i2cId ) )) ) )
                {
                    if ( lBufferObj->operation == DRV_I2C_OP_WRITE_READ )
                    {

                        SYS_INT_SourceStatusClear(dObj->mstrInterruptSource);

                        dObj->task  = DRV_I2C_SEND_RANDOM_READ_DEVICE_ADDRESS;
                        
                        lBufferObj->operation = DRV_I2C_OP_READ;

                        lBufferObj->transferSize = lBufferObj->readtransferSize;    //Assign # of bytes to be read into transfer size

                        _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = DRV_I2C_SEND_RESTART_EVENT;
                                                        
                        PLIB_I2C_MasterStartRepeat (dObj->i2cId);

                    }
                    else
                    {

                    #if defined  __PIC32MZ &&  (__PIC32_FEATURE_SET0 == 'E') && (__PIC32_FEATURE_SET1 == 'C')
                    /*   Errata for PIC32MZ which requires reset of I2C module */

                        #ifdef MZ_EC_ERRATA_25_BB_STOP               //GJV        

                            /* Bit bang procedure for STOP */
                            starttime = ReadCoreTimer();
                            while(ReadCoreTimer()-starttime < BRG_1_TIME_0);

                            /* Disable I2C */
                            PLIB_I2C_Disable(i2cId);

                            /* Wait 2 BRG */
                            starttime = ReadCoreTimer();
                            while(ReadCoreTimer()- starttime < BRG_1_TIME_0);

                            /* Set SDA as I/P */
                            PLIB_PORTS_PinDirectionInputSet(PORTS_ID_0, dObj->portSDA, dObj->pinSDA);

                            /* Wait 3 BRG */
                            starttime = ReadCoreTimer();
                            while(ReadCoreTimer()- starttime < BRG_1_TIME_0);

                            PLIB_I2C_Enable(i2cId);
                            PLIB_PORTS_PinClear(PORTS_ID_0, dObj->portSDA, dObj->pinSDA);
                            PLIB_PORTS_PinSet(PORTS_ID_0, dObj->portSCL, dObj->pinSCL);
                            PLIB_PORTS_PinDirectionOutputSet(PORTS_ID_0, dObj->portSDA, dObj->pinSDA);
                            PLIB_PORTS_PinDirectionInputSet(PORTS_ID_0, dObj->portSCL, dObj->pinSCL);
                        #else
                            /* alternate method to do STOP (previous errata note) */  
                            PLIB_I2C_Disable(i2cId);
                            PLIB_I2C_Enable(i2cId);
                        #endif

                        /* End-of-Bit-Bang procedure for STOP */

                        if (lBufferObj)
                        {
                            lBufferObj->inUse = false;
                        }    

                        /* set buffer event complete status and callback here instead of STOP condition 
                        because STOP condition is PIC32MZ-EC is bit-banged and would not generate an interrupt  */
                        dObj->task = DRV_I2C_TASK_SEND_DEVICE_ADDRESS;

                        /*clear any previous status flags */
                        _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = 0;

                        /* set status to buffer event complete */
                        _DRV_I2C_CLIENT_OBJ(lBufferObj, status) |=
                                DRV_I2C_BUFFER_EVENT_COMPLETE;

                        if ( _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback) != NULL )
                        {
                            dObj->interruptNestingCount++;
                            
                            /* Give an indication to the higher layer upon successful transmission */
                            _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback)
                            ( DRV_I2C_BUFFER_EVENT_COMPLETE, (DRV_I2C_BUFFER_HANDLE)lBufferObj, 0x00 );
                            
                            dObj->interruptNestingCount--;
                        }
                    #else
                        dObj->task = DRV_I2C_TASK_PROCESS_STOP; 
                        PLIB_I2C_MasterStop (i2cId);
                    #endif

                    }
                }
                break;
            case DRV_I2C_TASK_SET_RCEN_ONLY:
                if ( PLIB_I2C_TransmitterByteHasCompleted (i2cId) ) 
                {
                    if ( PLIB_I2C_TransmitterByteWasAcknowledged(i2cId) )
                    {
                        if (PLIB_I2C_ReceiverByteAcknowledgeHasCompleted(i2cId))
                        {
                            PLIB_I2C_MasterReceiverClock1Byte (i2cId);
                            dObj->task = DRV_I2C_TASK_PROCESS_READ_ONLY;
                        }
                    }   
                    else
                    {
                        
                        #if defined  __PIC32MZ &&  (__PIC32_FEATURE_SET0 == 'E') && (__PIC32_FEATURE_SET1 == 'C')
                        /*   Errata for PIC32MZ which requires reset of I2C module */

                            dObj->task = DRV_I2C_TASK_SEND_DEVICE_ADDRESS;

                            /* alternate method to do STOP (previous errata note) */  

                            #ifdef MZ_EC_ERRATA_25_BB_STOP               //GJV
                                /* Bit bang procedure for STOP */

                                starttime = ReadCoreTimer();
                                while(ReadCoreTimer()-starttime < BRG_1_TIME_0);

                                /* Disable I2C */
                                PLIB_I2C_Disable(i2cId);

                                /* Wait 2 BRG */
                                starttime = ReadCoreTimer();
                                while(ReadCoreTimer()- starttime < BRG_1_TIME_0);

                                /* Set SDA as I/P */
                                PLIB_PORTS_PinDirectionInputSet(PORTS_ID_0, dObj->portSDA, dObj->pinSDA);

                                /* Wait 3 BRG */
                                starttime = ReadCoreTimer();
                                while(ReadCoreTimer()- starttime < BRG_1_TIME_0);

                                PLIB_I2C_Enable(i2cId);
                                PLIB_PORTS_PinClear(PORTS_ID_0, dObj->portSDA, dObj->pinSDA);
                                PLIB_PORTS_PinSet(PORTS_ID_0, dObj->portSCL, dObj->pinSCL);
                                PLIB_PORTS_PinDirectionOutputSet(PORTS_ID_0, dObj->portSDA, dObj->pinSDA);
                                PLIB_PORTS_PinDirectionInputSet(PORTS_ID_0, dObj->portSCL, dObj->pinSCL);

                                /* End-of-Bit-Bang procedure for STOP */
                            #else                                                   //GJV
                              PLIB_I2C_Disable(i2cId);
                              PLIB_I2C_Enable(i2cId);
                            #endif                                                  //GJV

                            if (lBufferObj)
                            {
                                lBufferObj->inUse = false;
                            }                                                                    

                            /*clear any previous status flags */
                            _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = 0;

                            /* set status to buffer event complete */
                            _DRV_I2C_CLIENT_OBJ(lBufferObj, status) |=
                                DRV_I2C_BUFFER_EVENT_COMPLETE;

                            /* Have a check here because DRV_I2C_ClientSetup function call is optional */                       //Issue Callback for STOP event
                            if ( _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback) != NULL )
                            {
                                dObj->interruptNestingCount++;
                                
                                /* Give an indication to the higher layer upon successful transmission */
                                _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback)
                                        ( DRV_I2C_BUFFER_EVENT_COMPLETE, (DRV_I2C_BUFFER_HANDLE)lBufferObj, 0x00 );
                                
                                dObj->interruptNestingCount--;
                            }
                        #else
                            dObj->task = DRV_I2C_TASK_PROCESS_STOP;                            
                            PLIB_I2C_MasterStop (i2cId);
                        #endif

                    }
                }
                break;
            case DRV_I2C_TASK_PROCESS_STOP:

//#if defined (DRV_I2C_INTERRUPT_MODE) && (DRV_I2C_INTERRUPT_MODE == true)
//                 _DRV_I2C_InterruptSourceDisable (_DRV_I2C_INT_SRC_GET(dObj->mstrInterruptSource));
//#endif
                 
                dObj->task = DRV_I2C_TASK_SEND_DEVICE_ADDRESS;
                
                if( lBufferObj->transferSize )
                {
                    _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = DRV_I2C_BUFFER_EVENT_ERROR;
                        
                }
                else
                {
                    _DRV_I2C_CLIENT_OBJ(lBufferObj, status) = DRV_I2C_BUFFER_EVENT_COMPLETE;
                        
                }                

               /* Have a check here because DRV_I2C_ClientSetup function call is optional */
                if ( _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback) != NULL )
                {
                    dObj->interruptNestingCount++;
                    
                    /* Give an indication to the higher layer upon successful transmission */
                    _DRV_I2C_CLIENT_OBJ(((DRV_I2C_CLIENT_OBJ *)lBufferObj->clientHandle), callback)
                    ( _DRV_I2C_CLIENT_OBJ(lBufferObj, status), (DRV_I2C_BUFFER_HANDLE)lBufferObj, 0x00 );
                    
                    dObj->interruptNestingCount--;
                }
                
                                 
                if (lBufferObj)
                {
                    lBufferObj->inUse = false;
                    Nop();
                }

                break;
            default:
                break;

        }

        /* This state is encountered when an error interrupt has occurred.
           or an error has occurred during read */

        if ( true == _DRV_I2C_InterruptSourceStatusGet ( dObj->errInterruptSource ) )
        {
            /* Check for the overflow error */
            if ( PLIB_I2C_ReceiverOverflowHasOccurred ( i2cId ) )
            {
                if ( PLIB_I2C_ExistsReceiverOverflow ( i2cId ) )
                {
                    PLIB_I2C_ReceiverOverflowClear ( i2cId );
                }
            }

            _DRV_I2C_InterruptSourceClear ( dObj->errInterruptSource );
        }

        if (SYS_INT_SourceStatusGet(dObj->mstrInterruptSource))
        {
            SYS_INT_SourceStatusClear(dObj->mstrInterruptSource);
        }
        if (SYS_INT_SourceStatusGet(dObj->slaveInterruptSource))
        {
            SYS_INT_SourceStatusClear(dObj->slaveInterruptSource);
            PLIB_I2C_SlaveClockRelease ( i2cId );
        }
        if (SYS_INT_SourceStatusGet(dObj->errInterruptSource))
        {
            SYS_INT_SourceStatusClear(dObj->errInterruptSource);
        }
        
        if ( (dObj->i2cMode) == DRV_I2C_MODE_MASTER)
        {
            if ( (lBufferObj != NULL) &&  ((_DRV_I2C_CLIENT_OBJ(lBufferObj, status) == DRV_I2C_BUFFER_EVENT_COMPLETE) || (_DRV_I2C_CLIENT_OBJ(lBufferObj, status) == DRV_I2C_BUFFER_EVENT_ERROR) ))
            {                
                _DRV_I2C_Advance_Queue(dObj);
                if ((_DRV_I2C_IsQueueEmpty(dObj) == false))
                {
                    if (PLIB_I2C_BusIsIdle(dObj->i2cId))
                    {                
                        PLIB_I2C_MasterStart(dObj->i2cId);
                        Nop();
                    }
                }
            }
        }


}   /* DRV_I2C_TASKS */


//******************************************************************************
/* Function:
    DRV_HANDLE DRV_I2C_Open ( const SYS_MODULE_INDEX    index,
                             const DRV_IO_INTENT       intent )

  Summary:
    Opens the specific module instance and returns a handle

  Description:
    This routine opens a driver for use by any client module and provides a
    handle that must be provided to any of the other driver operations to
    identify the caller and the instance of the driver/hardware module.

  Parameters:
    index           - Identifier for the instance to be initialized
    ioIntent        - Possible values from the enumeration DRV_IO_INTENT

  Returns:
    If successful, the routine returns a valid open-instance handle (a number
    identifying both the caller and the module instance)
    If an error occurs, the return value is DRV_HANDLE_INVALID
*/

DRV_HANDLE DRV_I2C_Open ( const SYS_MODULE_INDEX   drvIndex,
                         const DRV_IO_INTENT      ioIntent )
{
    /* Multi client variables are removed from single client builds. */
   
    DRV_I2C_OBJ         *dObj;
    size_t              iClient;
    
    /* Validate the driver index */
    if( drvIndex >= DRV_I2C_INSTANCES_NUMBER )
    {
        return DRV_HANDLE_INVALID;
    }
    dObj = _DRV_I2C_INSTANCE_GET(drvIndex);

    /* Check for exclusive access */
    _DRV_I2C_LockMutex(dObj);
    
    /* Check if max number of clients open */
    if ( ( dObj->isExclusive == true ) ||
         ( dObj->inUse != true ) ||
         (( dObj->numClients > 0 ) &&
            DRV_IO_ISEXCLUSIVE( ioIntent )) ||
         (dObj->numClients >= DRV_I2C_CLIENTS_NUMBER))
    {
        /* Set that the hardware instance is opened in exclusive mode */
        _DRV_I2C_UnlockMutex(dObj);
         return DRV_HANDLE_INVALID;
    }
    _DRV_I2C_UnlockMutex(dObj);

    
    if(OSAL_MUTEX_Lock(&(gDrvI2CCommonDataObj.mutexClientObjects), OSAL_WAIT_FOREVER) == OSAL_RESULT_TRUE)
    {
        /* Setup client operations */
        /* Find available slot in array of client objects */
        for ( iClient = 0; iClient < DRV_I2C_CLIENTS_NUMBER ; iClient++ )
        {
            DRV_I2C_CLIENT_OBJ  *clientObj      =
                            ( DRV_I2C_CLIENT_OBJ* ) _DRV_I2C_CLIENT_OBJ_GET(iClient);
            if ( !clientObj->inUse )
            {
                /* Increment the client in case of Multi client support, otherwise remove
                the below statement */

                dObj->numClients++;

                /* Update that, the client is opened in exclusive access mode */
                if( DRV_IO_ISEXCLUSIVE( ioIntent ) )
                {
                    dObj->isExclusive = true;
                }
                clientObj->inUse  = true;
                
                /* We have found a client object. Release the mutex */

                OSAL_MUTEX_Unlock(&(gDrvI2CCommonDataObj.mutexClientObjects));

    //            _DRV_I2C_UnlockMutex(dObj);
                clientObj->driverObject = dObj;
                clientObj->intent = ioIntent;

                /* Return the client object */
                return ( DRV_HANDLE ) clientObj;
            }
        }
        
        /* Could not find a client object. Release the mutex and
           return with an invalid handle. */
        OSAL_MUTEX_Unlock(&(gDrvI2CCommonDataObj.mutexClientObjects));
    }
//    _DRV_I2C_UnlockMutex(dObj);

    return  DRV_HANDLE_INVALID ;
} /* DRV_I2C_Open */


//******************************************************************************
/* Function:
    void DRV_I2C_Close ( DRV_HANDLE handle )

  Summary:
    Closes an opened-instance of a driver

  Description:
    This routine closes an opened-instance of a driver, invalidating the given
    handle.

  Parameters:
    handle       - A valid open-instance handle, returned from the driver's
                   open routine

  Returns:
    None
*/

void DRV_I2C_Close ( DRV_HANDLE handle )
{
    /* Multi client variables are removed from single client builds. */
    DRV_I2C_CLIENT_OBJ *clientObj = (DRV_I2C_CLIENT_OBJ*)handle;

    if (clientObj->inUse == false)
    {
        //_DRV_I2C_UnlockMutex(clientObj->driverObject);
        return;
    }

    /* Free the Client Instance */
	if (clientObj->driverObject != NULL)
	{
		clientObj->driverObject->numClients --;
		clientObj->driverObject->isExclusive = false;
	}
    clientObj->inUse = false ;

} /* DRV_I2C_Close */


// *****************************************************************************
/* Function:
    void DRV_I2C_ClientSetup ( DRV_HANDLE handle,
                                 const DRV_I2C_CLIENT_SETUP * const config )

  Summary:
    Sets up the device communication parameters

  Description:
    This function sets up the device communication parameters

  Parameters:
    handle       - A valid open-instance handle, returned from the driver's
                   open routine

    config       - Port parameters tied to IRQ line

  Returns:
    None
*/

void DRV_I2C_ClientSetup ( DRV_HANDLE handle,
                                 const DRV_I2C_CLIENT_SETUP * const config )
{
//    bool temp;
    DRV_I2C_CLIENT_OBJ *clientObj = (DRV_I2C_CLIENT_OBJ*) handle;


    _DRV_I2C_SAVE_LAST_CLIENT();
//    temp = config->irqSetupLogicLevel;

    clientObj->irqSelectLogicLevel  = config->irqSetupLogicLevel;
    clientObj->irqSelectPort        = config->irqSetupPort;
    clientObj->irqSelectBitPos      = config->irqSetupBitPos;

    SYS_PORTS_PinDirectionSelect( PORTS_ID_0, SYS_PORTS_DIRECTION_OUTPUT,
            clientObj->irqSelectPort, clientObj->irqSelectBitPos);
    if (clientObj->irqSelectLogicLevel == true)
        SYS_PORTS_PinSet (PORTS_ID_0, clientObj->irqSelectPort, clientObj->irqSelectBitPos );
    else
        SYS_PORTS_PinClear (PORTS_ID_0, clientObj->irqSelectPort, clientObj->irqSelectBitPos );

}  /* DRV_I2C_ClientSetup */

//******************************************************************************
/* Function:
    void DRV_I2C_BufferEventHandlerSet ( const DRV_HANDLE handle,
                    const DRV_I2C_BUFFER_EVENT_HANDLER eventHandler,
                    const uintptr_t context )

  Summary:
	Adds a callback function for a client.

  Description:
    This routine adds a callback function for a client.

  Parameters:
        handle       	- A valid open-instance handle, returned from the driver's
						open routine.

	eventHandler    - Call back function.

	context		 	-  context.

  Returns:
    None.
*/

void DRV_I2C_BufferEventHandlerSet (const DRV_HANDLE handle,
                    const DRV_I2C_BUFFER_EVENT_HANDLER eventHandler,
                    const uintptr_t context )
{
	( (DRV_I2C_CLIENT_OBJ *) handle)->callback = eventHandler;

	( (DRV_I2C_CLIENT_OBJ *) handle)->context = context;
}   /* DRV_I2C_BufferEventHandlerSet */


//******************************************************************************
/* Function:
    DRV_I2C_BUFFER_HANDLE DRV_I2C_Receive  (    DRV_HANDLE handle,
                                                uint8_t* address,
                                                void *rxBuffer,
                                                size_t size,
                                                void * context);

  Summary:
    Adds a buffer to queue with a read request. Driver will process this
    request in the task routine.

  Description:
    This routine adds a buffer to queue with a read request. Driver will process
    this request in the task routine.

  Parameters:
    handle      - A valid open-instance handle, returned from the driver's open
                  routine
    address     - Device address of slave. If this API is used in Slave mode,
                  then a dummy value can be used
    buffer      - This buffer holds data is received
    size        - The number of bytes that the Master expects to read from Slave.
                  This value can be kept as the MAX BUFFER SIZE for slave.
                  This is because the Master controls when the READ operation
                  is terminated.
    callbackContext     - Not implemented, future expansion

  Returns:
    DRV_I2C_BUFFER_HANDLE using which application can track the current status of
    the buffer.
*/


DRV_I2C_BUFFER_HANDLE DRV_I2C_Receive   (   DRV_HANDLE handle, 
                                            uint16_t address,
                                            void *buffer,
                                            size_t size,
                                            void * callbackContext )
{
    DRV_I2C_BUFFER_OBJECT   *i2cDataObj;
    DRV_I2C_OBJ             *dObj = ((DRV_I2C_CLIENT_OBJ *) handle)->driverObject;

    /* Get a slot in the queue */
   i2cDataObj = _DRV_I2C_QueueSlotGet ( dObj );


    if ( i2cDataObj != NULL )
    {
        /* Fill the data directly to the queue. Set the inUse flag only at the end */
        i2cDataObj->clientHandle    = handle;
        if (address > ADDRESS_7BIT_UPPER_LIMIT )
        {
            i2cDataObj->slaveaddresshighbyte = (uint8_t)((address & 0xFF00)>>8);
            i2cDataObj->slaveaddresslowbyte  = (uint8_t)(address & 0x00FF);
        }
        else
        {
            i2cDataObj->slaveaddresshighbyte = (uint8_t)(address & 0x00FF);
            i2cDataObj->slaveaddresslowbyte  = 0;
        }
        i2cDataObj->operation       = DRV_I2C_OP_READ;
        i2cDataObj->txBuffer        = NULL;
        i2cDataObj->rxBuffer        = buffer;
        i2cDataObj->transferSize    = size;
        i2cDataObj->actualtransfersize = 0;
        i2cDataObj->status          = DRV_I2C_BUFFER_EVENT_PENDING;
        i2cDataObj->context         = callbackContext;
        i2cDataObj->transmitForced  = false;

        _DRV_I2C_QueuePush( dObj, i2cDataObj);

        if ( (_DRV_I2C_OPERATION_MODE_GET(dObj->i2cMode)) == DRV_I2C_MODE_MASTER)
        {
            
            /*  if either START and STOP were not detected which is true the 
                first time OR if STOP was detected, then it assumed the 
                transaction on the bus is complete */
            
            if ( ((!(PLIB_I2C_StartWasDetected(dObj->i2cId))) && (!(PLIB_I2C_StopWasDetected(dObj->i2cId)))) ||
                    (PLIB_I2C_StopWasDetected(dObj->i2cId)) )
            {
                
                /* if Bus IDLE and I2CxMIF = 0, then I2C is not running*/
                
                if ( (PLIB_I2C_BusIsIdle(dObj->i2cId)) &&
                       (!(SYS_INT_SourceStatusGet(dObj->mstrInterruptSource))) )
                {
//                    SYS_INT_SourceStatusClear(dObj->mstrInterruptSource);
                    _DRV_I2C_InterruptSourceEnable( dObj->mstrInterruptSource ) ;
                    _DRV_I2C_InterruptSourceEnable( dObj->errInterruptSource );
                    dObj->task = DRV_I2C_TASK_SEND_DEVICE_ADDRESS;
                    PLIB_I2C_MasterStart(dObj->i2cId);
                }
            }
        }
        else
        {
            SYS_INT_SourceStatusClear(dObj->slaveInterruptSource);
            _DRV_I2C_InterruptSourceEnable( dObj->slaveInterruptSource ) ;
        }
        return (DRV_I2C_BUFFER_HANDLE)i2cDataObj;
    }
    return (DRV_I2C_BUFFER_HANDLE)NULL;
}   /* DRV_I2C_Receive */


//******************************************************************************
/* Function:
    DRV_I2C_BUFFER_HANDLE DRV_I2C_BufferAddRead (   DRV_HANDLE handle,
                                                    uint8_t* address,
                                                    void *rxBuffer,
                                                    size_t size,
                                                    void * context);

  Summary:
    Adds a buffer to queue with a read request. Driver will process this
    request in the task routine.

  Description:
    This routine adds a buffer to queue with a read request. Driver will process
    this request in the task routine.

  Parameters:
    drvHandle   - A valid open-instance handle, returned from the driver's open
                  routine
    address     - Device address of slave. If this API is used in Slave mode,
                  then a dummy value can be used
    rxBuffer    - This buffer holds data is received
    size        - The number of bytes that the Master expects to read from Slave.
                  This value can be kept as the MAX BUFFER SIZE for slave.
                  This is because the Master controls when the READ operation
                  is terminated.
    context     - Not implemented, future expansion

  Returns:
    DRV_I2C_BUFFER_HANDLE using which application can track the current status of
    the buffer.
*/


DRV_I2C_BUFFER_HANDLE DRV_I2C_BufferAddRead (   DRV_HANDLE handle, 
                                                uint8_t* address,
                                                void *rxBuffer,
                                                size_t size,
                                                void * context )
{
    DRV_I2C_BUFFER_OBJECT   *i2cDataObj;
    DRV_I2C_OBJ             *dObj = ((DRV_I2C_CLIENT_OBJ *) handle)->driverObject;

    /* Get a slot in the queue */
   i2cDataObj = _DRV_I2C_QueueSlotGet ( dObj );


    if ( i2cDataObj != NULL )
    {
        /* Fill the data directly to the queue. Set the inUse flag only at the end */
        i2cDataObj->clientHandle            = handle;
        i2cDataObj->slaveaddresshighbyte    = *(address);
        i2cDataObj->slaveaddresslowbyte     = 0x00;
        i2cDataObj->operation               = DRV_I2C_OP_READ;
        i2cDataObj->txBuffer                = NULL;
        i2cDataObj->rxBuffer                = rxBuffer;
        i2cDataObj->transferSize            = size;
        i2cDataObj->actualtransfersize      = 0;
        i2cDataObj->status                  = DRV_I2C_BUFFER_EVENT_PENDING;
        i2cDataObj->context                 = context;
        i2cDataObj->transmitForced          = false;

        _DRV_I2C_QueuePush( dObj, i2cDataObj);

        if ( (_DRV_I2C_OPERATION_MODE_GET(dObj->i2cMode)) == DRV_I2C_MODE_MASTER)
        {
            /*  if either START and STOP were not detected which is true the 
                first time OR if STOP was detected, then it assumed the 
                transaction on the bus is complete */
            
            if ( ((!(PLIB_I2C_StartWasDetected(dObj->i2cId))) && (!(PLIB_I2C_StopWasDetected(dObj->i2cId)))) ||
                    (PLIB_I2C_StopWasDetected(dObj->i2cId)) )
            {
            
                /* if Bus IDLE and I2CxMIF = 0, then I2C is not running*/
                
                if ( (PLIB_I2C_BusIsIdle(dObj->i2cId)) &&
                       (!(SYS_INT_SourceStatusGet(dObj->mstrInterruptSource))) )
                {
//                    SYS_INT_SourceStatusClear(dObj->mstrInterruptSource);
                    _DRV_I2C_InterruptSourceEnable( dObj->mstrInterruptSource ) ;
                    
                    _DRV_I2C_InterruptSourceEnable( dObj->errInterruptSource );
                    dObj->task = DRV_I2C_TASK_SEND_DEVICE_ADDRESS;
                    PLIB_I2C_MasterStart(dObj->i2cId);
                }
            }
        }
        else
        {
            SYS_INT_SourceStatusClear(dObj->slaveInterruptSource);
            _DRV_I2C_InterruptSourceEnable( dObj->slaveInterruptSource ) ;
        }
        return (DRV_I2C_BUFFER_HANDLE)i2cDataObj;
    }
    return (DRV_I2C_BUFFER_HANDLE)NULL;
}   /* DRV_I2C_BufferAddRead */


//******************************************************************************
/* Function:
    DRV_I2C_BUFFER_HANDLE DRV_I2C_Transmit  (   DRV_HANDLE handle,
                                                uint16_t address,
                                                void *txBuffer,
                                                size_t size,
                                                void * context);
  Summary:
    Adds a buffer to queue with a write request. Driver will process this
    request in the task routine.

  Description:
    This routine adds a buffer to queue with a read request. Driver will process
    this request in the task routine.

  Parameters:
    handle      - A valid open-instance handle, returned from the driver's open
                  routine
    address     - Device address of slave. If this API is used in Slave mode,
                  then a dummy value can be used
    buffer      - Contains data to be transferred
    size        - The number of bytes that the Master expects to write to Slave.
                  This value can be kept as the MAX BUFFER SIZE for slave.
                  This is because the Master controls when the WRITE operation
                  is terminated.
    callbackContext     - Not implemented, future expansion

  Returns:
    DRV_I2C_BUFFER_HANDLE using which application can track the current status of
    the buffer.
*/

DRV_I2C_BUFFER_HANDLE DRV_I2C_Transmit (    DRV_HANDLE handle, 
                                            uint16_t address,
                                            void *writeBuffer,
                                            size_t size,
                                            void * callbackContext)
{
    DRV_I2C_BUFFER_OBJECT *i2cDataObj;
    DRV_I2C_OBJ *dObj = ((DRV_I2C_CLIENT_OBJ *) handle)->driverObject;

    /* Get a slot in the queue */
    i2cDataObj = _DRV_I2C_QueueSlotGet (dObj);

    if ( i2cDataObj != NULL )
    {
        /* Fill the data directly to the queue. Set the inUse flag only at the end */
        i2cDataObj->clientHandle    = handle;
        if (address > ADDRESS_7BIT_UPPER_LIMIT )
        {
            i2cDataObj->slaveaddresshighbyte = (uint8_t)((address & 0xFF00)>>8);
            i2cDataObj->slaveaddresslowbyte  = (uint8_t)(address & 0x00FF);
        }
        else
        {
            i2cDataObj->slaveaddresshighbyte = (uint8_t)(address & 0x00FF);
            i2cDataObj->slaveaddresslowbyte  = 0;
        }
        i2cDataObj->operation       = DRV_I2C_OP_WRITE;
        i2cDataObj->txBuffer        = writeBuffer;
        i2cDataObj->rxBuffer        = NULL;
        i2cDataObj->transferSize    = size;
        i2cDataObj->actualtransfersize = 0;
        i2cDataObj->status          = DRV_I2C_BUFFER_EVENT_PENDING;
        i2cDataObj->context         = callbackContext;
        i2cDataObj->transmitForced  = false;

        _DRV_I2C_QueuePush( dObj, i2cDataObj);

        if ( (_DRV_I2C_OPERATION_MODE_GET(dObj->i2cMode)) == DRV_I2C_MODE_MASTER)
        {
            /*  if either START and STOP were not detected which is true the 
                first time OR if STOP was detected, then it assumed the 
                transaction on the bus is complete */
            
            if ( ((!(PLIB_I2C_StartWasDetected(dObj->i2cId))) && (!(PLIB_I2C_StopWasDetected(dObj->i2cId)))) ||
                    (PLIB_I2C_StopWasDetected(dObj->i2cId)) )
            {
                            
                /* if Bus IDLE and I2CxMIF = 0, then I2C is not running*/
                
                if ( (PLIB_I2C_BusIsIdle(dObj->i2cId)) &&
                       (!(SYS_INT_SourceStatusGet(dObj->mstrInterruptSource))) )
                {
//                    SYS_INT_SourceStatusClear(dObj->mstrInterruptSource);
                    _DRV_I2C_InterruptSourceEnable( dObj->mstrInterruptSource ) ;
                    
                    _DRV_I2C_InterruptSourceEnable( dObj->errInterruptSource );
                    dObj->task = DRV_I2C_TASK_SEND_DEVICE_ADDRESS;
                    PLIB_I2C_MasterStart(dObj->i2cId);
                }
            }
        }
        else
        {
           SYS_INT_SourceStatusClear(dObj->slaveInterruptSource);
           _DRV_I2C_InterruptSourceEnable( dObj->slaveInterruptSource ) ;

        }
        return (DRV_I2C_BUFFER_HANDLE) i2cDataObj;
    }
    return (DRV_I2C_BUFFER_HANDLE)NULL;
} /* DRV_I2C_Transmit */


//******************************************************************************
/* Function:
    DRV_I2C_BUFFER_HANDLE DRV_I2C_BufferAddWrite (  DRV_HANDLE handle,
                                                    uint8_t* address,
                                                    void *txBuffer,
                                                    size_t size,
                                                    void * context);
  Summary:
    Adds a buffer to queue with a write request. Driver will process this
    request in the task routine.

  Description:
    This routine adds a buffer to queue with a read request. Driver will process
    this request in the task routine.

  Parameters:
    drvHandle   - A valid open-instance handle, returned from the driver's open
                  routine
    slaveaddress- Device address of slave. If this API is used in Slave mode,
                  then a dummy value can be used
    txBuffer    - Contains data to be transffered
    size        - The number of bytes that the Master expects to write to Slave.
                  This value can be kept as the MAX BUFFER SIZE for slave.
                  This is because the Master controls when the WRITE operation
                  is terminated.
    context     - Not implemented, future expansion

  Returns:
    DRV_I2C_BUFFER_HANDLE using which application can track the current status of
    the buffer.
*/

DRV_I2C_BUFFER_HANDLE DRV_I2C_BufferAddWrite (  DRV_HANDLE handle, 
                                                uint8_t* address,
                                                void *txBuffer,
                                                size_t size,
                                                void * context)
{
    DRV_I2C_BUFFER_OBJECT *i2cDataObj;
    DRV_I2C_OBJ *dObj = ((DRV_I2C_CLIENT_OBJ *) handle)->driverObject;

    /* Get a slot in the queue */
    i2cDataObj = _DRV_I2C_QueueSlotGet (dObj);

    if ( i2cDataObj != NULL )
    {
        /* Fill the data directly to the queue. Set the inUse flag only at the end */
        i2cDataObj->clientHandle                = handle;
        i2cDataObj->slaveaddresshighbyte        = *(address);
        i2cDataObj->slaveaddresslowbyte         = 0x00;
        i2cDataObj->operation                   = DRV_I2C_OP_WRITE;
        i2cDataObj->txBuffer                    = txBuffer;
        i2cDataObj->rxBuffer                    = NULL;
        i2cDataObj->transferSize                = size;
        i2cDataObj->actualtransfersize          = 0;
        i2cDataObj->status                      = DRV_I2C_BUFFER_EVENT_PENDING;
        i2cDataObj->context                     = context;
        i2cDataObj->transmitForced              = false;

        _DRV_I2C_QueuePush( dObj, i2cDataObj);

        if ( (_DRV_I2C_OPERATION_MODE_GET(dObj->i2cMode)) == DRV_I2C_MODE_MASTER)
        {
            
            /*  if either START and STOP were not detected which is true the 
                first time OR if STOP was detected, then it assumed the 
                transaction on the bus is complete */
            
            if ( ((!(PLIB_I2C_StartWasDetected(dObj->i2cId))) && (!(PLIB_I2C_StopWasDetected(dObj->i2cId)))) ||
                    (PLIB_I2C_StopWasDetected(dObj->i2cId)) )
            {
                        
                /* if Bus IDLE and I2CxMIF = 0, then I2C is not running*/
                
                if ( (PLIB_I2C_BusIsIdle(dObj->i2cId)) &&
                       (!(SYS_INT_SourceStatusGet(dObj->mstrInterruptSource))) )
                {
//                    SYS_INT_SourceStatusClear(dObj->mstrInterruptSource);
                    _DRV_I2C_InterruptSourceEnable( dObj->mstrInterruptSource ) ;
                    
                    _DRV_I2C_InterruptSourceEnable( dObj->errInterruptSource );
                    dObj->task = DRV_I2C_TASK_SEND_DEVICE_ADDRESS;
                    PLIB_I2C_MasterStart(dObj->i2cId);
                }
            }
        }
        else
        {
           SYS_INT_SourceStatusClear(dObj->slaveInterruptSource);
           _DRV_I2C_InterruptSourceEnable( dObj->slaveInterruptSource ) ;

        }
        return (DRV_I2C_BUFFER_HANDLE) i2cDataObj;
    }
    return (DRV_I2C_BUFFER_HANDLE)NULL;
} /* DRV_I2C_BufferAddWrite */

//******************************************************************************
/* Function:
    DRV_I2C_BUFFER_HANDLE DRV_I2C_TransmitReceive ( DRV_HANDLE handle,
                                                    uint8_t* address,
                                                    void *txBuffer,
                                                    size_t wsize,
                                                    void *rxBuffer,
                                                    size_t rsize,
                                                    void * context);

  Summary:
    This function writes data to Slave, inserts restart and requests read from
    slave.

  Description:
    Master calls this function to send a register address value to the slave and
    then queries the slave with a read request to read the contents indexed by
    the register location. The Master sends a restart condition after the
    initial write before sending the device address with R/W = 1. The restart
    condition prevents the Master from relinquishing the control of the bus. The
    slave should not use this function. Driver will process this request
    in the task routine.

  Parameters:
    handle      - A valid open-instance handle, returned from the driver's open
                  routine
    address     - Device address of slave. If this API is used in Slave mode,
                  then a dummy value can be used
    writeBuffer - Contains data to be transferred
    writeSize   - The number of bytes that the Master expects to write to Slave.
                  This value can be kept as the MAX BUFFER SIZE for slave.
                  This is because the Master controls when the WRITE operation
                  is terminated.
    readBuffer  - This buffer holds data that is send back from slave after
                  read operation.
    readSize    - The number of bytes the Master expects to be read from the
                  slave
    callbackContext     - Not implemented, future expansion

  Returns:
    DRV_I2C_BUFFER_HANDLE using which application can track the current status of
    the buffer.
*/

DRV_I2C_BUFFER_HANDLE DRV_I2C_TransmitThenReceive   (   DRV_HANDLE handle, 
                                                        uint16_t address,
                                                        void *writeBuffer,
                                                        size_t writeSize,
                                                        void *readBuffer,
                                                        size_t readSize,
                                                        void * callbackContext)
{
    DRV_I2C_BUFFER_OBJECT *i2cDataObj;
    DRV_I2C_OBJ *dObj = ((DRV_I2C_CLIENT_OBJ *) handle)->driverObject;

     /* Get a slot in the queue */
    i2cDataObj = _DRV_I2C_QueueSlotGet (dObj);

    if ( i2cDataObj != NULL )
    {
      /* Fill the data directly to the queue. Set the inUse flag only at the end */
        i2cDataObj->clientHandle        = handle;
        if (address > ADDRESS_7BIT_UPPER_LIMIT )
        {
            i2cDataObj->slaveaddresshighbyte = (uint8_t)((address & 0xFF00)>>8);
            i2cDataObj->slaveaddresslowbyte  = (uint8_t)(address & 0x00FF);
        }
        else
        {
            i2cDataObj->slaveaddresshighbyte = (uint8_t)(address & 0x00FF);
            i2cDataObj->slaveaddresslowbyte  = 0;
        }
        i2cDataObj->operation           = DRV_I2C_OP_WRITE_READ;
        i2cDataObj->txBuffer            = writeBuffer;
        i2cDataObj->transferSize        = writeSize;
        i2cDataObj->rxBuffer            = readBuffer;
        i2cDataObj->readtransferSize    = readSize;
        i2cDataObj->actualtransfersize  = 0;
        i2cDataObj->status              = DRV_I2C_BUFFER_EVENT_PENDING;
        i2cDataObj->context             = callbackContext;
        i2cDataObj->transmitForced      = false;

        _DRV_I2C_QueuePush( dObj, i2cDataObj);

        if ( (_DRV_I2C_OPERATION_MODE_GET(dObj->i2cMode)) == DRV_I2C_MODE_MASTER)
        {
           
            /*  if either START and STOP were not detected which is true the 
                first time OR if STOP was detected, then it assumed the 
                transaction on the bus is complete */
            
            if ( ((!(PLIB_I2C_StartWasDetected(dObj->i2cId))) && (!(PLIB_I2C_StopWasDetected(dObj->i2cId)))) ||
                    (PLIB_I2C_StopWasDetected(dObj->i2cId)) )
            {
            
                /* if Bus IDLE and I2CxMIF = 0, then I2C is not running*/
                
                if ( (PLIB_I2C_BusIsIdle(dObj->i2cId)) &&
                       (!(SYS_INT_SourceStatusGet(dObj->mstrInterruptSource))) )
                {
//                    SYS_INT_SourceStatusClear(dObj->mstrInterruptSource);
                    _DRV_I2C_InterruptSourceEnable( dObj->mstrInterruptSource ) ;
                    
                    _DRV_I2C_InterruptSourceEnable( dObj->errInterruptSource );
                    dObj->task = DRV_I2C_TASK_SEND_DEVICE_ADDRESS;
                    PLIB_I2C_MasterStart(dObj->i2cId);
                }
            }
        }
        else
        {
           SYS_INT_SourceStatusClear(dObj->slaveInterruptSource);
           _DRV_I2C_InterruptSourceEnable( dObj->slaveInterruptSource ) ;

        }
        return (DRV_I2C_BUFFER_HANDLE) i2cDataObj;
    }
     return (DRV_I2C_BUFFER_HANDLE)NULL;
} /* DRV_I2C_TransmitThenReceive */

//******************************************************************************
/* Function:
    DRV_I2C_BUFFER_HANDLE DRV_I2C_BufferAddWriteRead (  DRV_HANDLE handle,
                                                        uint8_t* address,
                                                        void *txBuffer,
                                                        size_t wsize,
                                                        void *rxBuffer,
                                                        size_t rsize,
                                                        void * context);

  Summary:
    This function writes data to Slave, inserts restart and requests read from
    slave.

  Description:
    Master calls this function to send a register address value to the slave and
    then queries the slave with a read request to read the contents indexed by
    the register location. The Master sends a restart condition after the
    initial write before sending the device address with R/W = 1. The restart
    condition prevents the Master from relinquishing the control of the bus. The
    slave should not use this function. Driver will process this request
    in the task routine.

  Parameters:
    drvHandle   - A valid open-instance handle, returned from the driver's open
                  routine
    address     - Device address of slave. If this API is used in Slave mode,
                  then a dummy value can be used
    txBuffer    - Contains data to be transffered
    wsize       - The number of bytes that the Master expects to write to Slave.
                  This value can be kept as the MAX BUFFER SIZE for slave.
                  This is because the Master controls when the WRITE operation
                  is terminated.
    rxBuffer    - This buffer holds data that is send back from slave after
                  read operation.
    rsize       - The number of bytes the Master expects to be read from the
                  slave
    context     - Not implemented, future expansion

  Returns:
    DRV_I2C_BUFFER_HANDLE using which application can track the current status of
    the buffer.
*/

DRV_I2C_BUFFER_HANDLE DRV_I2C_BufferAddWriteRead (  DRV_HANDLE handle, 
                                                    uint8_t* address,
                                                    void *txBuffer,
                                                    size_t wsize,
                                                    void *rxBuffer,
                                                    size_t rsize,
                                                    void * context)
{
    DRV_I2C_BUFFER_OBJECT *i2cDataObj;
    DRV_I2C_OBJ *dObj = ((DRV_I2C_CLIENT_OBJ *) handle)->driverObject;

     /* Get a slot in the queue */
    i2cDataObj = _DRV_I2C_QueueSlotGet (dObj);
    
    if ( i2cDataObj != NULL )
    {
      /* Fill the data directly to the queue. Set the inUse flag only at the end */
        i2cDataObj->clientHandle                = handle;
        i2cDataObj->slaveaddresshighbyte        = *(address);
        i2cDataObj->slaveaddresslowbyte         = 0x00;
        i2cDataObj->operation                   = DRV_I2C_OP_WRITE_READ;
        i2cDataObj->txBuffer                    = txBuffer;
        i2cDataObj->transferSize                = wsize;
        i2cDataObj->rxBuffer                    = rxBuffer;
        i2cDataObj->readtransferSize            = rsize;
        i2cDataObj->actualtransfersize          = 0;
        i2cDataObj->status                      = DRV_I2C_BUFFER_EVENT_PENDING;
        i2cDataObj->context                     = context;
        i2cDataObj->transmitForced              = false;

        _DRV_I2C_QueuePush( dObj, i2cDataObj);

        if ( (_DRV_I2C_OPERATION_MODE_GET(dObj->i2cMode)) == DRV_I2C_MODE_MASTER)
        {
            
            /*  if either START and STOP were not detected which is true the 
                first time OR if STOP was detected, then it assumed the 
                transaction on the bus is complete */
            
            if ( ((!(PLIB_I2C_StartWasDetected(dObj->i2cId))) && (!(PLIB_I2C_StopWasDetected(dObj->i2cId)))) ||
                    (PLIB_I2C_StopWasDetected(dObj->i2cId)) )
            {
            
                /* if Bus IDLE and I2CxMIF = 0, then I2C is not running*/
                
                if ( (PLIB_I2C_BusIsIdle(dObj->i2cId)) &&
                       (!(SYS_INT_SourceStatusGet(dObj->mstrInterruptSource))) )
                {
//                    SYS_INT_SourceStatusClear(dObj->mstrInterruptSource);
                    _DRV_I2C_InterruptSourceEnable( dObj->mstrInterruptSource ) ;
                    
                    _DRV_I2C_InterruptSourceEnable( dObj->errInterruptSource );
                    dObj->task = DRV_I2C_TASK_SEND_DEVICE_ADDRESS;
                    PLIB_I2C_MasterStart(dObj->i2cId);
                }
            }
        }
        else
        {
           SYS_INT_SourceStatusClear(dObj->slaveInterruptSource);
           _DRV_I2C_InterruptSourceEnable( dObj->slaveInterruptSource ) ;

        }
        return (DRV_I2C_BUFFER_HANDLE) i2cDataObj;
    }
     return (DRV_I2C_BUFFER_HANDLE)NULL;
} /* DRV_I2C_BufferAddWrite */

// *****************************************************************************
/* Function:
    DRV_I2C_BUFFER_EVENT DRV_I2C_BufferStatus ( DRV_I2C_BUFFER_HANDLE bufferHandle )

  Summary:
    Returns the transmitter and receiver transfer status

  Description:
    This returns the transmitter and receiver transfer status.

  Parameters:
   
    handle          - A valid open-instance handle, returned from the driver's 
                      open routine 
    bufferHandle    - A valid open-instance handle, returned when calling the 
                      BufferAddRead/BufferAddWrite/BufferAddReadWrite function

  Returns:
    A DRV_I2C_TRANSFER_STATUS value describing the current status of the
    transfer.
*/

DRV_I2C_BUFFER_EVENT DRV_I2C_TransferStatusGet  ( DRV_HANDLE handle,
                                                  DRV_I2C_BUFFER_HANDLE bufferHandle )
{
    /* return the transfer status. This doesn't have any protection */

    return _DRV_I2C_DATA_OBJ(bufferHandle, status);

} /* DRV_I2C_TransferStatus */

// *****************************************************************************
/* Function:
    DRV_I2C_BUFFER_EVENT DRV_I2C_BufferStatus ( DRV_I2C_BUFFER_HANDLE bufferHandle )

  Summary:
    Returns the transmitter and receiver transfer status

  Description:
    This returns the transmitter and receiver transfer status.

  Parameters:
    handle       - A valid open-instance handle, returned from the driver's
                   open routine

  Returns:
    A DRV_I2C_TRANSFER_STATUS value describing the current status of the
    transfer.
*/

DRV_I2C_BUFFER_EVENT DRV_I2C_BufferStatus ( DRV_I2C_BUFFER_HANDLE bufferHandle )
{
    /* return the transfer status. This doesn't have any protection */

    return _DRV_I2C_DATA_OBJ(bufferHandle, status);

} /* DRV_I2C_TransferStatus */


// *****************************************************************************
/* Function:
    uint32_t DRV_I2C_BytesTransferred ( DRV_I2C_BUFFER_HANDLE bufferHandle )

  Summary:
    Returns the number of bytes transmitted or received in a particular I2C 
    transaction. The transaction is identified by the handle.

  Description:
    This returns the transmitter and receiver transfer status.

  Parameters:
   
    handle      - A valid open-instance handle, returned from the driver's open
                  routine 
    bufferHandle  -  A valid open-instance handle, returned when calling the 
                     BufferAddRead/BufferAddWrite/BufferAddReadWrite function

  Returns:
    The number of bytes transferred in a particular I2C transaction. 
*/

uint32_t DRV_I2C_BytesTransferred ( DRV_HANDLE handle,
                                    DRV_I2C_BUFFER_HANDLE bufferHandle )
{
    /* returns the number of bytes in an I2C transaction */

    return _DRV_I2C_DATA_OBJ(bufferHandle, actualtransfersize);

} /* DRV_I2C_BytesTransferred */



//******************************************************************************
/* Function:
    unsigned int DRV_I2C_VersionGet( const SYS_MODULE_INDEX drvIndex )

  Summary:
    Gets I2C driver version in numerical format.

  Description:
    This routine gets the I2C driver version. The version is encoded as
    major * 10000 + minor * 100 + patch. The stringized version can be obtained
    using DRV_I2C_VersionStrGet()

  Parameters:
    None.

  Returns:
    Current driver version in numerical format.
*/

unsigned int DRV_I2C_VersionGet( const SYS_MODULE_INDEX drvIndex )
{
    return( ( _DRV_I2C_VERSION_MAJOR * 10000 ) +
            ( _DRV_I2C_VERSION_MINOR * 100 ) +
            ( _DRV_I2C_VERSION_PATCH ) );

} /* DRV_I2C_VersionGet */


// *****************************************************************************
/* Function:
    char * DRV_I2C_VersionStrGet ( const SYS_MODULE_INDEX drvIndex )

  Summary:
    Gets I2C driver version in string format.

  Description:
    This routine gets the I2C driver version. The version is returned as
    major.minor.path[type], where type is optional. The numerical version can
    be obtained using DRV_I2C_VersionGet()

  Parameters:
    None.

  Returns:
    Current I2C driver version in the string format.

  Remarks:
    None.
*/

char * DRV_I2C_VersionStrGet( const SYS_MODULE_INDEX drvIndex )
{
    return _DRV_I2C_VERSION_STR;

} /* DRV_I2C_VersionStrGet */

// *****************************************************************************
/*
  Remarks:
    The functions DRV_I2C_StopEventSend, DRV_I2C_RestartEventSend and 
    and DRV_I2C_IRQEventSend are deprecated but maintained for backward 
    compatibility
*/

void DRV_I2C_StopEventSend(DRV_HANDLE handle)
{
    DRV_I2C_OBJ *dObj = ((DRV_I2C_CLIENT_OBJ *) handle)->driverObject;
    if ( (_DRV_I2C_OPERATION_MODE_GET(dObj->i2cMode)) == DRV_I2C_MODE_MASTER)
    {
        PLIB_I2C_MasterStop (dObj->i2cId);
    }
}

void DRV_I2C_RestartEventSend(DRV_HANDLE handle)
{
    DRV_I2C_OBJ *dObj = ((DRV_I2C_CLIENT_OBJ *) handle)->driverObject;

    if ( (_DRV_I2C_OPERATION_MODE_GET(dObj->i2cMode)) == DRV_I2C_MODE_MASTER)
    {
        PLIB_I2C_MasterStartRepeat (dObj->i2cId);
    }
}

void DRV_I2C_IRQEventSend(DRV_HANDLE handle)
{
    DRV_I2C_CLIENT_OBJ *clientObj = (DRV_I2C_CLIENT_OBJ*) handle;

    DRV_I2C_OBJ  *dObj = ((DRV_I2C_CLIENT_OBJ *) handle)->driverObject;

    if ( (_DRV_I2C_OPERATION_MODE_GET(dObj->i2cMode)) == DRV_I2C_MODE_SLAVE)
    {
        PLIB_PORTS_PinClear(PORTS_ID_0, clientObj->irqSelectPort, clientObj->irqSelectBitPos);
        dObj->modulemainstate = DRV_I2C_SLAVE_READY_TO_TX_TO_MASTER;
    }
}

void DRV_I2C_QueueFlush ( DRV_HANDLE handle )
{
    uint16_t index;
    
    DRV_I2C_OBJ  *dObj = ((DRV_I2C_CLIENT_OBJ *) handle)->driverObject;
    
    SYS_MODULE_INDEX drvIndex = dObj->drvIndex;
        
    DRV_I2C_BUFFER_OBJECT *lQueueObj;
    
    dObj->queueHead = NULL;
    
    dObj->queueIn = 0;
    
    dObj->queueOut = 0;

    for ( index=0; index<DRV_I2C_NUM_OF_BUFFER_OBJECTS; index++ )
    {
        lQueueObj = &gDrvI2CBufferObj [ drvIndex ][ index ];

        lQueueObj->inUse    = false;
        
        lQueueObj->next     = NULL;
        
        lQueueObj->status   = DRV_I2C_BUFFER_EVENT_COMPLETE;
    }
    
    /* When an I2C transaction is attempted without any pull-ups on the bus
       I2C Master ISR is triggered for START condition, but also Bus Exception
       ISR is also triggered, to clear BCL bit, I2C has to reset */
    
    SYS_INT_SourceStatusClear(dObj->errInterruptSource);
    PLIB_I2C_Disable (dObj->i2cId);
    PLIB_I2C_Enable (dObj->i2cId);
}


/*******************************************************************************
End of File
*/



